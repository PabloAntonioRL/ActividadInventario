const path = require('path');
const webpack = require("webpack");

const HtmlWebpackPlugin = require("html-webpack-plugin");
const MiniCssExtractPlugin = require("mini-css-extract-plugin");
const CopyWebpackPlugin = require("copy-webpack-plugin");


module.exports = {
    entry: './js/main.js',
    output: {
        filename: 'js/main.js',
        path: path.resolve(__dirname, 'dist')
    },
    devServer: {
        static: path.resolve(__dirname),
        port: 3001,
        hot: true
    },
    module: {
        rules: [
            {
            test: /\.css$/i,
            use: [
              {loader: MiniCssExtractPlugin.loader, options: {}},
              "css-loader"
            ]
          }
        ]
    },
    plugins: [
        new webpack.ProgressPlugin(),
        new CopyWebpackPlugin({
          patterns: [{
            from: "./",
            to: "./",
            noErrorOnMissing: true,
            globOptions: {
              //we can safely ignore all files that are handled by loaders/plugins.
              ignore: [
                //"**/main.js",
                "**/*.js",
                "**/*.jsx",
                "**/*.css",
                "**/*.ts",
                "**/*.tsx",
                "**/*.html",
                "**/package.json",
                "**/package-lock.json",
                "**/tsconfig.json",
                "**/node_modules/**/*",
                "**/.git",
                "**/dist",
                "**/export",
                "**/nbproject",
                "**/distOld"
              ]
            }
          }]
        }),
        new HtmlWebpackPlugin({
          template: "./public/index.html",
          filename: "index.html",
          inject: "body"
        }),
        new MiniCssExtractPlugin({
          filename: "css/styles.css", 
          chunkFilename: "css/styles.css"
        })
    ]
};
