/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

import { modules } from './modules';
import { setActiveSidebar } from './sidebar';



let currentModule = null;

async function loadModule(moduleId) {
    const moduleDef = modules.find(m => m.id === moduleId);
    if (!moduleDef) {
        console.warn(`Módulo no encontrado: ${moduleId}`);
        return;
    }

    if (currentModule?.unmount) {
        currentModule.unmount();
    }

    const container = document.getElementById('content');
    container.innerHTML = '';

    const module = (await moduleDef.load()).default;
    module.mount(container);

    currentModule = module;
    setActiveSidebar(moduleId);
}

export function navigate(moduleId) {
    if (window.location.hash !== `#${moduleId}`) {
        window.location.hash = moduleId;
    } else {
        loadModule(moduleId);
    }
}

function handleHashChange() {
    let moduleId = window.location.hash.replace('#', '');
    if (moduleId) {
        if(moduleId.indexOf("?")>=0) {
            moduleId = moduleId.slice(0, moduleId.indexOf("?"));
        }
        loadModule(moduleId);
    }
}

export function initRouter(defaultModule) {
    window.addEventListener('hashchange', handleHashChange);

    if (window.location.hash) {
        handleHashChange();
    } else {
        navigate(defaultModule);
    }
    
}


export function fetchModuleHtml(module, file) {
    const BASE_PATH = (() => {
        const path = window.location.pathname;
        return path.substring(0, path.lastIndexOf("/") + 1);
    })();

    return fetch(`${BASE_PATH}public/modules/${module}/${file}`);
}

