/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Other/javascript.js to edit this template
 */

import { renderSidebar } from './sidebar';
import { initRouter } from './router';

import "../css/styles.css";

document.addEventListener("DOMContentLoaded", init);
const version = "0.0.0";

async function init() {
    console.log("Iniciando plataforma");
    console.warn("Version: "+version);
    renderSidebar();
    initRouter(); // módulo por defecto
    
}


