/* 
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
export function formatLabel(key){
    if(!key) return "";
    try {
        return key
            .replace(/([a-z])([A-Z])/g,"$1 $2")
            .replace(/^./,function(c){
                return c.toUpperCase();
            });
    } catch(e) {
        console.error(e);
    }
}
var noclone = ["reference", "reference3d", "reference3D", "formatter", "formartter", "map"];
function clone(obj, exclude) {
    var newObj = {};
    exclude = exclude || [];
    for(var key in obj) {
        var value = obj[key];
        try {
            if(exclude.includes(key)===true) continue;
            if(noclone.includes(key)===true || key.charAt(0)==="_") {
                newObj[key] = value;
                continue;
            }
            switch(typeof value) {
                case "object": 
                    if(value !== null && typeof value.length==="undefined") {
                        newObj[key] = clone(value);
                    } else newObj[key] = value;
                    break;
                case "function":
                default:
                    newObj[key] = value;
                    break;
            }
        } catch(e) {
            console.error(e);
            newObj[key] = value;
        }
    }
    return newObj;
}

function getUrlQueryParameters(defaults, top) {
    defaults = defaults || {};
    var query = window.location.search;
    if(top === true) query = window.top.location.search;
    if(!query)
        return defaults;
    if (!query || query.length <= 1) {
      return defaults;
    }
    query = parseQuery(query);
    for (var attrname in defaults) {
      if (!query.hasOwnProperty(attrname)) {
        query[attrname] = defaults[attrname];
      }
    }
    return query;
  }
  
export function obtenerParametrosURL() {
    const hash = window.location.hash.substring(1);
    const [modulo, queryString = ""] = hash.split("?");
    const params = new URLSearchParams(queryString);
    // Convertir todos los parámetros en un objeto
    const parametros = Object.fromEntries(params.entries());
    return {
        modulo: modulo,
        ...parametros
    };
}

function createIconsSVG(icons) {
    icons.forEach(function (icon) {
        var url = icon.url;
        var div = icon.container;
        var btn = document.getElementById(div);
        var handeler = function (iconA) {
            btn.innerHTML = null;
            btn.appendChild(iconA.image);
            var classes = icon.classes;
            if(classes) {
                classes.forEach(function (c) {
                    iconA.image.classList.add(c);
                });
            }
            var style = icon.style;
            if(style) {
                for(var s in style)
                    iconA.style[s] = style[s];
            }
        };
        if(btn)
            var svg = new SVGManager(url, handeler);
    });
}

function getMounthFullName (m) {
    m = parseInt(m);
    switch(m) {
        case 1: return "Enero"; case 2: return "Febrero";
        case 3: return "Marzo"; case 4: return "Abril";
        case 5: return "Mayo"; case 6: return "Junio";
        case 7: return "Julio"; case 8: return "Agosto";
        case 9: return "Septiembre"; case 10: return "Octubre";
        case 11: return "Noviembre"; case 12: return "Diciembre";
    }
}
function getMounthShortName (m) {
    m = parseInt(m);
    switch(m) {
        case 1: return "Ene"; case 2: return "Feb";
        case 3: return "Mar"; case 4: return "Abr";
        case 5: return "May"; case 6: return "Jun";
        case 7: return "Jul"; case 8: return "Ago";
        case 9: return "Sep"; case 10: return "Oct";
        case 11: return "Nov"; case 12: return "Dic";
    }
}

function formatDate(time, format) {
    var date = time? new Date(time) : new Date();
    var y = date.getFullYear();
    var mo = (date.getMonth()+1)<10? "0"+(date.getMonth()+1): (date.getMonth()+1);
    var d = date.getDate() <10? "0"+date.getDate(): date.getDate();
    var h = date.getHours() <10 ? "0"+date.getHours(): date.getHours();
    var m = date.getMinutes() <10 ? "0"+date.getMinutes(): date.getMinutes();
    var s = date.getSeconds() <10 ? "0"+date.getSeconds(): date.getSeconds();
    switch(format) {
        //default: return format.replace(`DD`,d < 10 ? '0' + d : d).replace(`MM`, mo < 10 ? '0' + mo : mo).replace(`YYYY`, y).replace(`Month`, formatFecha(month)).replace(`hh`, hour < 10 ? '0' + hour : hour).replace(`mm`, min < 10 ? '0' + min : min).replace(`ss`, sec < 10 ? '0' + sec : sec);

        default: 
            if(format) {
                var result = "";
                if(format.indexOf("MM")>=0 || format.indexOf("AAAA")>=0 || format.indexOf("DD")) {
                    result = format.replace("AAAA", y)
                            .replace("hh:mm:ss.ms", formatTime2(time, true, true))
                            .replace("hh:mm:ss", formatTime(time, true))
                            .replace("hh:mm", formatTime(time, false))
                            .replace("MM", mo).replace("DD", d);
                }
                if(result.indexOf("Mname") || result.indexOf("MSname")) {
                    result = result.replace("Mname", getMounthFullName(mo)).replace("MSname", getMounthShortName(mo));
                }
                return result;
            }
            return y+"-"+mo+"-"+d+" "+formatTime(time, false);
        case "aaaa-mm-dd hh:mm:ss.ms": return y+"-"+mo+"-"+d+" "+formatTime2(time, true, true);
        case "aaaa/mm/dd": return y+"/"+mo+"/"+d;
        case "aaaa/mm/dd hh:mm": return y+"/"+mo+"/"+d+" "+formatTime(time, false);
        case "aaaa/mm/dd hh:mm:ss": return y+"/"+mo+"/"+d+" "+formatTime(time);
        case "mm/dd/aaaa": return mo+"/"+d+"/"+y;
        case "ddmmaaaa": return d+mo+y+"";
        case "dd/mm/aaaa": return d+"/"+mo+"/"+y;
        case "dd/mm/aaaa hh:mm": return d+"/"+mo+"/"+y+" "+formatTime(time, false);
        case "dd/mm/aaaa hh:mm:ss": return d+"/"+mo+"/"+y+" "+formatTime(time);
        case "dd-mm-aaaa": return d+"-"+mo+"-"+y;
        case "mm/aaaa": return mo+"/"+y;
        case "dd/mm": return d+"/"+mo;
        case "dd-mm-aaaaThh:mm":return d+"-"+mo+"-"+y+"T"+formatTime(time, false);
        case "aaaammdd": return y+""+mo+""+d+"";
        case "aaaa-mm-dd hh:mm:ss": return y+"-"+mo+"-"+d+" "+formatTime(time);
        case "aaaa-mm-dd hh:mm": return y+"-"+mo+"-"+d+" "+formatTime(time, false);
        case "aaaa-mm-ddThh:mm": return y+"-"+mo+"-"+d+"T"+formatTime(time, false);
        case "aaaa-mm-ddThh:mm:ss": return y+"-"+mo+"-"+d+"T"+formatTime(time);
        case "aaaa-mm-dd": return y+"-"+mo+"-"+d;
        case "aaaa-mm-dd hh:mm AM": return y+"-"+mo+"-"+d+" "+formatTime(time, false, false);
        case "aaaa-mm-dd hh:mm PM": return y+"-"+mo+"-"+d+" "+formatTime(time, false, false);
        case "mm-dd hh:mm": return mo+"-"+d+" "+formatTime(time, false);
        case "mm-dd": return mo+"-"+d;
        case "date": return date;
        case "time": return date.getTime();
        case "aaaammddhh": return ""+y+mo+d+(date.getHours()<10 ? "0"+date.getHours(): date.getHours());
        case "aaaa/mm/dd hh": return y+"/"+mo+"/"+d+" "+(date.getHours()<10 ? "0"+date.getHours(): date.getHours());
        case "aaaa-mm-dd hh": return y+"-"+mo+"-"+d+" "+(date.getHours()<10 ? "0"+date.getHours(): date.getHours());
            case "aaaammddhhmmss": return y+mo+d+h+m+s;
            case "AAAAMMDDhhmmss": return y+mo+d+h+m+s;
    }
    return  mo+"/"+d+"/"+y;
}
function formatTime2(time, includeS, includeMs) {
        var date = time? new Date(time) : new Date();
        var h = date.getHours() <10 ? "0"+date.getHours(): date.getHours();
        var m = date.getMinutes() <10 ? "0"+date.getMinutes(): date.getMinutes();
        var s = date.getSeconds() <10 ? "0"+date.getSeconds(): date.getSeconds();
        var ms = date.getMilliseconds();
        if(includeS===false)
            return h+":"+m;
        else {
            if(includeMs === true)
                return h+":"+m+":"+s+"."+ms;
            else
                return h+":"+m+":"+s;
        }
}
function formatTime(time, includeS, format24) {
        var date = time? new Date(time) : new Date();
        var h = date.getHours() <10 ? "0"+date.getHours(): date.getHours();
        var m = date.getMinutes() <10 ? "0"+date.getMinutes(): date.getMinutes();
        var s = date.getSeconds() <10 ? "0"+date.getSeconds(): date.getSeconds();
        if(format24 === false) {
            var x = h>12? "PM": "AM";
            h = h>12? h-12: h;
            if(includeS===false)
                return h+":"+m+" "+x;
            else
                return h+":"+m+":"+s+" "+x;
        } else {
            if(includeS===false)
                return h+":"+m;
            else
                return h+":"+m+":"+s;
        }
}

function formatearMinutos(minutos) {
  const horas = Math.floor(minutos / 60);
  const mins = minutos % 60;
  
  if (horas > 0 && mins > 0) {
    return `${horas}H ${mins} min`;
  } else if (horas > 0) {
    return `${horas}H`;
  } else {
    return `${mins} min`;
  }
}


function formatDateUTC(time, format) {
        var now = time? new Date(time): new Date();
        var offset = (now.getTimezoneOffset() * 60000);
        //var date = new Date( now.getTime() + offset);
        return formatDate(now.getTime() + offset, format);
}
function formatDateUTCToLocal(time, format) {
        var now = time? new Date(time): new Date();
        var date = new Date(now.getTime()+now.getTimezoneOffset());
        var offset = (now.getTimezoneOffset() / 60);//+ (1000*60*60);
        var hours = now.getHours();
        date.setHours(hours - offset);
        return formatDate(date.getTime(), format);
}

function esNumero (texto) {
    if(typeof texto === "string") {
        var x = parseFloat(texto);
        if(isNaN(x))
            return false;
        else
           return true;
    }
    if(typeof texto === 'number')
        return true;
    return false;
}
function numeroMes(mes) {
        switch(mes.toLowerCase()) {
            case "ene":
            case "enero": return 1;
            case "feb":
            case "febrero": return 2;
            case "mar":
            case "marzo": return 3;
            case "abr":
            case "abril": return 4;
            case "may":
            case "mayo": return 5;
            case "jun": 
            case "junio": return 6;
            case "jil":
            case "julio": return 7;
            case "ago":
            case "agosto": return 8;
            case "sep":
            case "septiembre": return 9;
            case "oct":
            case "octubre": return 10;
            case "nov":
            case "noviembre": return 11;
            case "dic":
            case "diciembre": return 12;
            default: return 1;
        }
}
function nombreMes(m) {
    switch(m) {
        default: return "Sin definir";
        case 1: return "Enero";
        case 2: return "Febrero";
        case 3: return "Marzo";
        case 4: return "Abril";
        case 5: return "Mayo";
        case 6: return "Junio";
        case 7: return "Julio";
        case 8: return "Agosto";
        case 9: return "Septiembre";
        case 10: return "Octubre";
        case 11: return "Noviembre";
        case 12: return "Diciembre";
    }
}
    
function numeroDia(dia) {
        switch(dia.toLowerCase()) {
            case "lunes": return 1;
            case "martes": return 2;
            case "miercoles": return 3;
            case "jueves": return 4;
            case "viernes": return 5;
            case "sabado": return 6;
            case "domingo": return 7;
        }
}
function exportarJson(content, name) {
    if(content===null) return;
    var dataType = 'data:text/plain;charset=utf-8';
    var a = document.createElement('a');
    if(typeof content ==="object") content = JSON.stringify(content, null, 4);
    a.href = dataType +', '+ content;
    a.download = (name || formatDate("","ddmmaaa"))+".json";
    a.click();
}
function exportarTxt(content, name) {
    var dataType = 'data:text/plain;charset=utf-8';
    var a = document.createElement('a');
    a.href = dataType +', '+ content;
    a.download = (name || formatDate("","ddmmaaa"))+".txt";
    a.click();
}
function exportarTablaXLS(boton, divTabla, name) {
    boton.preventDefault();
    var dataType = 'data:application/vnd.ms-excel:base64';
    var tableDiv = document.getElementById(divTabla);
    var tableHTML = tableDiv.outerHTML.replace(/ /g, '%20').replace(/#/g, "");
    var a = document.createElement('a');
    a.href = dataType +', '+ tableHTML;
    a.download = (name || formatDate("","ddmmaaa"))+".xls";
    a.click();
}
 function exportarArrayCSV(boton, table, name) {
    if(boton)
        boton.preventDefault();
    var dataType = 'data:text/csv;charset=utf-8';
    var csvString = table.join("\r\n");
    var csvData = new Blob(["\uFEFF"+csvString], { type: 'text/csv;charset=utf-8' }); 
    var csvUrl = URL.createObjectURL(csvData);
    //var tableHTML = tableDiv.outerHTML.replace(/ /g, '%20').replace(/#/g, "");
    var a = document.createElement('a');
    a.href = csvUrl;
    a.download = (name || formatDate("","ddmmaaa"))+".csv";
    a.click();
}
function exportarTablaCSV(div, filename) {
    var csv = [];
    var rows = document.querySelectorAll(div+" tr");
    for (var i = 0; i < rows.length; i++) {
        var row = [], cols = rows[i].querySelectorAll("td, th");
        for (var j = 0; j < cols.length; j++) {
            var v = cols[j].innerText;
            if(v.indexOf(",")>=0) v = '"'+v+'"';
            row.push(v);
        }
        csv.push(row.join(","));        
    }
    var csvFile;
    var downloadLink;

    csvFile = new Blob(["\uFEFF"+csv.join("\r\n")], {type: 'text/csv;charset=utf-8'});
    downloadLink = document.createElement("a");
    downloadLink.download = filename+".csv";
    downloadLink.href = window.URL.createObjectURL(csvFile);
    downloadLink.style.display = "none";
    document.body.appendChild(downloadLink);
    downloadLink.click();

}
/*
* 
* @param {type} div
* @param {type} opciones
* @returns {undefined}
*/
function setOptions (div, options, firstOption, valueOptions) {
    document.getElementById(div).innerHTML = "";
    var base = "<option value='$VALUE'>$LABEL</option>", etiqueta = "";
    if(firstOption !== false) {
        if(!firstOption)
            firstOption = firstOption || "Todos";
        etiqueta = base.replace("$VALUE", 0).replace("$LABEL", firstOption);
    }

    var  n = options.length, values=false;
    if(valueOptions) {
        if(valueOptions.length === n)
            values = true;
    }
    for(var i =0; i<n; i++) {
        if(values)
            etiqueta += base.replace("$VALUE", valueOptions[i]).replace("$LABEL", options[i]);
        else 
            etiqueta += base.replace("$VALUE", i+1).replace("$LABEL", options[i]);
    }
    document.getElementById(div).innerHTML = etiqueta;
}

var startTime={}, endTime={};
function startTimer(id) {
    startTime[id] = Date.now();
}
function endTimer(id) {
    if(!startTime[id]) {
        console.log("No tiempo de inicio para "+id);
        return 0;
    }
    var stringSTime = formatTime(startTime[id]);
    console.log("Start Timer id = "+id+" Time = "+stringSTime);
    endTime[id] = Date.now();
    var finalTime = endTime[id] - startTime[id];
    var stringFTime = formatTime(endTime[id]);
    console.log("Final time id = "+id+" Time "+stringFTime);
    var h, m, s;
    //ms = finalTime % 1000;
    s = finalTime / 1000;
    m = parseInt(s / 60);
    h = parseInt(m / 60);
    var stringTime = h+":"+m+":"+s;
    console.log("Tiempo total id "+id+" "+stringTime);
    return finalTime;
}
        
function getRandom(min, max) {
    return Math.random() * (max - min) + min;
}

function normalizarTexto(texto, eliminarEspacios) {
    if(!texto) return "";
    if(typeof texto !=="string") {
        try {
            texto = texto +"";
        } catch(e) {
            console.error(e);
        }
    }
  return texto
    .normalize("NFD")                    // separa acentos de letras
    .replace(/[\u0300-\u036f]/g, "")     // elimina los acentos
    .toLowerCase()                       // convierte a minúsculas
    .replace(/[^a-z0-9\s]/g, "")         // elimina caracteres especiales (deja letras, números y espacios)
    .replace(/\s+/g, eliminarEspacios ? "" : " "); // elimina o reduce espacios
}

function diffInMinutes(fechaStr) {
    if (!fechaStr) return null;

    // Convertir "YYYY-MM-DD hh:mm:ss" → "YYYY-MM-DDThh:mm:ss"
    const normalized = fechaStr.replace(" ", "T");

    const fecha = new Date(normalized);
    const ahora = new Date();

    if (isNaN(fecha.getTime())) {
        throw new Error("Formato de fecha inválido");
    }

    const diffMs = ahora - fecha; // diferencia en milisegundos
    const diffMin = Math.floor(diffMs / (1000 * 60));

    return diffMin;
}
function isOlderThan2Months(fechaStr) {
    if (!fechaStr) return false;

    const normalized = fechaStr.replace(" ", "T");
    const fecha = new Date(normalized);

    if (isNaN(fecha.getTime())) {
        throw new Error("Formato de fecha inválido");
    }

    const limite = new Date();
    limite.setMonth(limite.getMonth() - 2);

    return fecha < limite;
}
function isOlderThanXDays(fechaStr, dias) {
    if (!fechaStr || typeof dias !== "number") return false;

    // Normalizar formato
    const normalized = fechaStr.replace(" ", "T");
    const fecha = new Date(normalized);

    if (isNaN(fecha.getTime())) {
        throw new Error("Formato de fecha inválido");
    }

    // Fecha límite (hoy - X días)
    const limite = new Date();
    limite.setDate(limite.getDate() - dias);

    return fecha < limite;
}

function formatLastTime(eventDate, isUtc = false) {
    if (typeof eventDate === "string") {
        if (eventDate.charAt(0) === "+" || eventDate.charAt(0) === "-")
            return eventDate;
    }
    var date;
    if (isUtc) {
        // Si viene como string sin zona horaria, forzamos UTC agregando Z
        if (typeof eventDate === "string" && !eventDate.endsWith("Z")) {
            date = new Date(eventDate + "Z");
        } else {
            date = new Date(eventDate);
        }
    } else {
        date = new Date(eventDate);
    }
    if (isNaN(date.getTime()))
        return "-";
    var now = Date.now();
    var time = now - date.getTime();
    time = time < 0 ? time * (-1) : time;
    var min = time / (1000 * 60);
    if (min < 1)
        return parseInt(min * 60) + " seg";
    if (min < 60)
        return parseInt(min) + " min";
    var h = parseInt(min / 60);
    min = parseInt(min % 60);
    if (h <= 24)
        return h + "h " + min + "min";
    var d = parseInt(h / 24);
    h = parseInt(h % 24);
    if (d < 30)
        return d + " d " + h + " h " + min + " min";
    return formatDate(date, "aaaa-mm-dd hh:mm");
}

function timeFormatStyle(min) {
    var style, original = min;
    if(typeof min === "string") {
        if(min.charAt(0) === "-")
            style = {color: coloresEstados[1]}; // verde 00b050 209306
        else        ///    naranja
            style = {color: coloresEstados[0]};
        return {value: min, style: style, originalValue: min};
    }
    var simbolo = min >= 0? '+': '-';
    if(simbolo === '-' || min===0)// verde coloresEstados[1]: coloresEstados[2];
        style = {color: coloresEstados[1]}; // verde 00b050 209306
    else        ///    naranja
        style = {color: coloresEstados[2]}; // rojo ff9900 cc3535
    min = simbolo ==='-'? min *(-1): min;
    if(min <60) {
        return {value: simbolo+" "+parseInt(min) +" min", style: style, originalValue: original};
    }
    var h = parseInt(min /60);
    min = parseInt(min % 60);
    if(h <=24) {
        return {value: simbolo+" "+h+":"+min+" h", style: style, originalValue: original};
    }
    var d = parseInt(h/24);
    h = parseInt(h % 24);
    return {value: simbolo+" "+d+" "+h+":"+min+" h", style: style, originalValue: original};
}
function customFormatDate(time) {
    if(typeof time==="undefined" || !time)
        return "Sin definir";
    if(typeof time === "string") {
        if(time.charAt(0) === "+" || time.charAt(0)==="-")
            return time;
    }
    var date = new Date(time);
    const meses = ['Ene', 'Feb', 'Mar', 'Abr', 'May', 'Jun', 'Jul', 'Ago', 'Sep', 'Oct', 'Nov', 'Dic'];
    const dias_semana = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
    var year = date.getFullYear();
    var mo = meses[date.getMonth()];
    var day = dias_semana[date.getDay()];
    var d = date.getDate();
    var string = date.toDateString();
    var h = date.getHours() <10 ? "0"+date.getHours(): date.getHours();
    var m = date.getMinutes() <10 ? "0"+date.getMinutes(): date.getMinutes();
    return d+" "+mo+" "+year+" | <b>"+h+":"+m+"</b>";
}

export {
    formatDate,
    formatDateUTC,
    formatDateUTCToLocal,
    formatTime,
    esNumero,
    numeroMes,
    numeroDia,
    exportarJson,
    exportarTablaXLS,
    exportarArrayCSV,
    exportarTablaCSV,
    setOptions,
    formatTime2,
    nombreMes,
    startTimer,
    endTimer,
    getRandom,
    clone,
    exportarTxt,
    normalizarTexto,
    formatearMinutos,
    diffInMinutes,
    isOlderThan2Months,
    isOlderThanXDays,
    
    formatLastTime,
    timeFormatStyle,
    customFormatDate
}