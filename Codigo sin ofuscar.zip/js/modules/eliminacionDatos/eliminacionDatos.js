/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */


let statusInterval = null;

export function destroyModule() {
    if (statusInterval) {
        clearInterval(statusInterval);
        statusInterval = null;
    }
}
export  function loadModule() {
    console.log("Cargando modulo Eliminacion de datos");
    
    const headerTitle = document.getElementById("sectionTitle");
    headerTitle.innerHTML = "Eliminación de Datos";
}