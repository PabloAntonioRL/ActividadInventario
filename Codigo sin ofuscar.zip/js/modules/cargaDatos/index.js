/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */


import {loadModule, destroyModule} from "./cargaDatos.js";
import {fetchModuleHtml} from "../../router.js";

export default {
    id: 'cargaDatos',
    title: 'Carga de Datos',

    async mount(container) {
        const html = await fetchModuleHtml("cargaDatos", "cargaDatos.html")
            .then(r => r.text());

        container.innerHTML = html;
        loadModule();
    },

    unmount() {
        destroyModule();
    }
};

