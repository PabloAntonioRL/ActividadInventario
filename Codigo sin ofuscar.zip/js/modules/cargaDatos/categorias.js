/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {submitCategoria, getDataFrom} from "../../consultasApi.js";
import {hideLoading, showLoading} from "./cargaDatos.js";
import {formatDate} from "../../Util.js";


// Inicializar eventos del formulario
export function initializeCategoriasForm() {
    const form = document.getElementById("formCategoria");
    const btnGuardar = document.getElementById("btnGuardarCategoria");
    const nombre = document.getElementById("nombre-categoria");
    nombre.addEventListener("input", () => {
        btnGuardar.disabled =
            nombre.value.trim().length === 0;
        nombre.value = nombre.value.toUpperCase();
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const isEdit = btnGuardar.innerText.indexOf("Actualizar")>=0;
        const validation = validateCategoria(isEdit);

        if (!validation.valid) {
            alert(validation.message);
            return;
        }
        showLoading();
        btnGuardar.disabled = true; 
        if(isEdit===false) {
            await submitCategoria("newCategory", validation.data, success=>{
                if(success === true) {
                    form.reset();
                    updateSelectCategoria();
                }
                btnGuardar.disabled =
                        nombre.value.trim().length === 0;
                hideLoading();
            });
        } else {
            await submitCategoria("updateCategory", validation.data, success=>{
                if(success === true) {
                    form.reset();
                    updateSelectCategoria();
                }
                btnGuardar.disabled =
                        nombre.value.trim().length === 0;
                hideLoading();
            });
        }
    });
    
    updateSelectCategoria();
    
    const btnClean = document.getElementById("clean-categoria");
    btnClean.addEventListener("clcik", ()=>{
        setCreateCategoria();
    });
}

export function setCreateCategoria() {
    const btnGuardar = document.getElementById("btnGuardarCategoria");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Crear Categoria`;
    const panelData = document.getElementById("edit-categoria");
    if(panelData.className.indexOf("hidden")===-1)
        panelData.classList.add("hidden");
    btnGuardar.disabled = true;
}
export function setUpdateCategoria(data) {
    const btnGuardar = document.getElementById("btnGuardarCategoria");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Actualizar Categoria`;
    fillform(data);
    const panelData = document.getElementById("edit-categoria");
    if(panelData.className.indexOf("hidden")>=0)
        panelData.classList.remove("hidden");
    btnGuardar.disabled = false;
}

function fillform(data) {
    try {
        showLoading();
        document.getElementById("nombre-categoria").value = data.nombre_categoria;
        document.getElementById("categoria-numero").value = data.numero_categoria;
        document.getElementById("categoria-activo").checked = data.activo;
        
        document.getElementById("categoria-fecha_alta").value = data.fecha_creacion? formatDate(data.fecha_creacion, "AAAA-MM-DD"): "";
        document.getElementById("categoria-fecha_baja").value = data.fecha_baja? formatDate(data.fecha_baja, "AAAA-MM-DD"): "";
        
        hideLoading();
    } catch(e) {
        console.error(e);
    }
}

// actualizar listas de clases
export function updateSelectCategoria() {
    showLoading();
    getDataFrom("categorias", null, data=> { 
        if(!data) {
            alert("No se encontro informaón de la categoria");
            return;
        }
        data = data.data || [];
        const divs = ["departamento-categoria","clase-categoria", "familia-categoria", "inventario-categoria"];
        divs.forEach(id=> {
            try {
                const select = document.getElementById(id);
                if(!select) return;
                select.innerHTML = "";
                select.disabled = false;
                const option = document.createElement("option");
                option.innerHTML = "Seleccionar Categoria";
                option.value = 0;
                select.appendChild(option);

                data.forEach(dep=>{
                    const o = document.createElement("option");
                    o.innerHTML = dep.nombre_categoria;
                    o.value = dep.numero_categoria;
                    select.appendChild(o);
                });
            } catch(e) {}
        });
        hideLoading();
    });
}

// Validar información del formulario
function validateCategoria(isEdit) {
    const nombreCategoria = document.getElementById("nombre-categoria");
    const nombre = nombreCategoria.value.trim();

    if (nombre.length === 0) {
        return {
            valid: false,
            message: "Debes ingresar el nombre del categoria."
        };
    }

    if (nombre.length > 100) {
        return {
            valid: false,
            message: "El nombre no puede superar los 100 categoria."
        };
    }
    
    if(isEdit===false) {
        return {
            valid: true,
            data: {
                nombre_categoria: nombre
            }
        };
    } else {
        const numDep = parseInt(document.getElementById("categoria-numero").value);
        if(isNaN(numDep) || !numDep ) {
            return {
                valid: false,
                message: "El numero es invalido."
            };
        }
        const activo = document.getElementById("categoria-activo").checked;
        return {
            valid: true,
            data: {
                nombre_categoria: nombre,
                numero_categoria: numDep,
                activo: activo
            }
        };
    }
}
