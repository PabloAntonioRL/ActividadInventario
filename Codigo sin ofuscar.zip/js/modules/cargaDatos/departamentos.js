/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {submitDepartamento, getDataFrom} from "../../consultasApi.js";
import {hideLoading, showLoading} from "./cargaDatos.js";
import {formatDate} from "../../Util.js";


// Inicializar eventos del formulario
export function initializeDepartamentoForm() {
    const form = document.getElementById("formDepartamento");
    const btnGuardar = document.getElementById("btnGuardarDepartamento");
    const nombre = document.getElementById("nombre-departamento");
    const numCat = document.getElementById("departamento-categoria");
    
    nombre.addEventListener("input", () => {
        if(numCat.value===0 || nombre.value.trim().length === 0)
            btnGuardar.disabled = true;
        else btnGuardar.disabled = false;
        nombre.value = nombre.value.toUpperCase();
    });
    
    numCat.addEventListener("input", () => {
        if(numCat.value===0 || nombre.value.trim().length === 0)
            btnGuardar.disabled = true;
        else btnGuardar.disabled = false;
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const isEdit = btnGuardar.innerText.indexOf("Actualizar")>=0;
        const validation = validateDepartamento(isEdit);

        if (!validation.valid) {
            alert(validation.message);
            return;
        }
        showLoading();
        btnGuardar.disabled = true;
        if(isEdit===false) {
            await submitDepartamento("newDepartment", validation.data, success=>{
                if(success === true) {
                    form.reset();
                    //updateSelectDepartamento(0, "departamento-categoria");
                }
                btnGuardar.disabled =
                        nombre.value.trim().length === 0;
                hideLoading();
            });
        } else {
            await submitDepartamento("updateDepartment", validation.data, success=>{
                if(success === true) {
                    form.reset();
                    //updateSelectDepartamento(0, "departamento-categoria");
                }
                btnGuardar.disabled =
                        nombre.value.trim().length === 0;
                hideLoading();
            });
        }
    });
    
    //updateSelectDepartamento();
    
    const btnClean = document.getElementById("clean-departamento");
    btnClean.addEventListener("clcik", ()=>{
        setCreateDepartamento();
    });
}

export function setCreateDepartamento() {
    const btnGuardar = document.getElementById("btnGuardarDepartamento");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Crear departamento`;
    const panelData = document.getElementById("edit-departamento");
    if(panelData.className.indexOf("hidden")===-1)
        panelData.classList.add("hidden");
    btnGuardar.disabled = true;
}
export function setUpdateDepartamento(data) {
    const btnGuardar = document.getElementById("btnGuardarDepartamento");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Actualizar departamento`;
    fillform(data);
    const panelData = document.getElementById("edit-departamento");
    if(panelData.className.indexOf("hidden")>=0)
        panelData.classList.remove("hidden");
    btnGuardar.disabled = false;
}

function fillform(data) {
    try {
        showLoading();
        document.getElementById("nombre-departamento").value = data.nombre_departamento;
        document.getElementById("departamento-numero").value = data.numero_departamento;
        document.getElementById("departamento-activo").checked = data.activo;
        
        document.getElementById("departamento-fecha_alta").value = data.fecha_creacion? formatDate(data.fecha_creacion, "AAAA-MM-DD"): "";
        document.getElementById("departamento-fecha_baja").value = data.fecha_baja? formatDate(data.fecha_baja, "AAAA-MM-DD"): "";
        
        window.setTimeout(()=> {
            document.getElementById("departamento-categoria").value = data.numero_categoria;
        }, 1000);
        hideLoading();
    } catch(e) {
        console.error(e);
    }
}

// actualizar listas de clases
export function updateSelectDepartamento(categoria, divId) {
    const select = document.getElementById(divId);
    select.innerHTML = "";
    const option = document.createElement("option");
    option.innerHTML = "Seleccionar Departamento";
    option.value = 0;
    select.appendChild(option);
    if(!categoria) {
        select.disabled = true;
        return;
    }
    showLoading();
    getDataFrom("departamentos", "numero_categoria="+categoria, data=> { 
        if(!data) {
            alert("No se encontro informaón de Departamentos");
            return;
        }
        data = data.data || [];
        //const divs = ["clase-departamento", "familia-departamento", "inventario-departamento"];
        //divs.forEach(id=> {
//            const select = document.getElementById(divId);
//            if(!select) return;
//            select.innerHTML = "";
            select.disabled = false;
//            const option = document.createElement("option");
//            option.innerHTML = "Seleccionar Departamento";
//            option.value = 0;
//            select.appendChild(option);
            
            data.forEach(dep=>{
                const o = document.createElement("option");
                o.innerHTML = dep.nombre_departamento;
                o.value = dep.numero_departamento;
                select.appendChild(o);
            });
        //});
        hideLoading();
    });
}

// Validar información del formulario
function validateDepartamento(isEdit) {
    const nombreDepartamento = document.getElementById("nombre-departamento");
    const nombre = nombreDepartamento.value.trim();

    if (nombre.length === 0) {
        return {
            valid: false,
            message: "Debes ingresar el nombre del departamento."
        };
    }

    if (nombre.length > 100) {
        return {
            valid: false,
            message: "El nombre no puede superar los 100 caracteres."
        };
    }
    
    const cat = document.getElementById("departamento-categoria");
    const numCat = parseInt(cat.value);
    if(isNaN(numCat) || numCat<=0) {
        return {
            valid: false,
            message: "Numero de categoria invalido"
        };
    }
    
    if(isEdit===false) {
        return {
            valid: true,
            data: {
                nombre_departamento: nombre,
                numero_categoria: numCat
            }
        };
    } else {
        const numDep = parseInt(document.getElementById("departamento-numero").value);
        if(isNaN(numDep) || !numDep ) {
            return {
                valid: false,
                message: "El numero es invalido."
            };
        }
        const activo = document.getElementById("departamento-activo").checked;
        return {
            valid: true,
            data: {
                numero_categoria: numCat,
                nombre_departamento: nombre,
                numero_departamento: numDep,
                activo: activo
            }
        };
    }
}
