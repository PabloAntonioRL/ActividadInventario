/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {getDataFrom, submitClase} from "../../consultasApi.js";
import {hideLoading, showLoading} from "./cargaDatos.js";
import {formatDate} from "../../Util.js";
import {updateSelectDepartamento} from "./departamentos.js";

// Inicializar formulario de clases
export function initClasesForm() {
    const form = document.getElementById("formClase");
    const btnGuardar = document.getElementById("btnGuardarClase");
    const nombre = document.getElementById("nombre-clase");
    const numCat = document.getElementById("clase-categoria");
    const numDep = document.getElementById("clase-departamento");
    
    nombre.addEventListener("input", () => {
        if(numCat.value!==0 && numDep.value!==0) {
            btnGuardar.disabled = nombre.value.trim().length === 0;
        }
        nombre.value = nombre.value.toUpperCase();
    });
    
    
    numCat.addEventListener("click", e=>{
        if(numCat.value!==0) {
            btnGuardar.disabled = nombre.value.trim().length === 0;
        }
        updateSelectDepartamento(parseInt(numCat.value), "clase-departamento");
    });
    numDep.addEventListener("click", e=>{
        if(numCat.value!==0 && numDep.value!==0) {
            btnGuardar.disabled = nombre.value.trim().length === 0;
        }
    });
    
    const btnClean = document.getElementById("clean-clase");
    btnClean.addEventListener("click", ()=>{
        updateSelectDepartamento(0, "clase-departamento");
        setCreateClase();
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const isEdit = btnGuardar.innerText.indexOf("Actualizar")>=0;
        const validation = validateClase(isEdit);

        if (!validation.valid) {
            alert(validation.message);
            return;
        }
        showLoading();
        btnGuardar.disabled = true;
        console.log(validation.data);
        //return;
        if(isEdit===false) {
            await submitClase("newClass", validation.data, success=>{
                if(success === true) 
                    form.reset();
                if(numCat.value!==0) {
                    btnGuardar.disabled = nombre.value.trim().length === 0;
                }
                hideLoading();
            });
        } else {
            await submitClase("updateClass", validation.data, success=>{
                if(success === true) {
                    form.reset();
                }
                if(numCat.value!==0) {
                    btnGuardar.disabled = nombre.value.trim().length === 0;
                }
                hideLoading();
            });
        }
    });
    //initSelectClases();
}

export function setCreateClase() {
    const btnGuardar = document.getElementById("btnGuardarClase");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Crear clase`;
    const panelData = document.getElementById("edit-clase");
    if(panelData.className.indexOf("hidden")===-1)
        panelData.classList.add("hidden");
    btnGuardar.disabled = true;
}
export function setUpdateClase(data) {
    const btnGuardar = document.getElementById("btnGuardarClase");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Actualizar clase`;
    fillform(data);
    const panelData = document.getElementById("edit-clase");
    if(panelData.className.indexOf("hidden")>=0)
        panelData.classList.remove("hidden");
    btnGuardar.disabled = false;
}

function fillform(data) {
    try {
        showLoading();
        document.getElementById("nombre-clase").value = data.nombre_clase;
        document.getElementById("clase-numero").value = data.numero_clase;
        document.getElementById("clase-activo").checked = data.activo;
        
        document.getElementById("clase-fecha_alta").value = data.fecha_creacion? formatDate(data.fecha_creacion, "AAAA-MM-DD"): "";
        document.getElementById("clase-fecha_baja").value = data.fecha_baja? formatDate(data.fecha_baja, "AAAA-MM-DD"): "";
        
        const numCat = data.numero_categoria;
        const numDep = data.numero_departamento;
        
        updateSelectDepartamento(numCat, "clase-departamento");
        window.setTimeout(()=>{
            document.getElementById("clase-categoria").value = numCat || 0;
            document.getElementById("clase-departamento").value = numDep || 0;
            hideLoading();
        }, 1000);
    } catch(e) {
        console.error(e);
    }
}

// inicializar listas de clases
//function initSelectClases() {
//    const divs = ["familia-clase", "inventario-clase"];
//    divs.forEach(id=>{
//        const select = document.getElementById(id);
//        select.addEventListener("change", e=>{
//            try {
//                const numCla = e.currentTarget.selectedOptions[0].value;
//                numCla = parseInt(numCla);
//            } catch(e) {
//                console.error(e);
//            }
//        });
//    });
//}
// actualizar lista de clases
export function updateSelectClases(numCat, numDep, divId) {
    const select = document.getElementById(divId);
    select.innerHTML = "";
    const option = document.createElement("option");
    option.innerHTML = "Seleccionar Clase";
    option.value = 0;
    select.appendChild(option);
    if(!numDep || !numCat) {
        select.disabled = true;
        return;
    }
    showLoading();
    getDataFrom("clases", "numero_categoria="+numCat+"&numero_departamento="+numDep, data=>{ 
        if(!data) {
            alert("No se encontro informaón de Clases");
            return;
        }
        data = data.data || [];
        data = data.filter(d=>{
            return d.numero_departamento===numDep;
        });
        if(data<=0) {
            hideLoading();
            return;
        }
        
        select.disabled = false;
        data.forEach(dep=>{
            const o = document.createElement("option");
            o.innerHTML = dep.nombre_clase;
            o.value = dep.numero_clase;
            select.appendChild(o);
        });
        hideLoading();
    });
}

function validateClase(isEdit) {
    const nombreInput = document.getElementById("nombre-clase");
    const nombre = nombreInput.value.trim();
    if (nombre.length === 0) {
        return {
            valid: false,
            message: "Debes ingresar el nombre de la clase."
        };
    }
    if (nombre.length > 100) {
        return {
            valid: false,
            message: "El nombre no puede superar los 100 caracteres."
        };
    }
    
    const cat = document.getElementById("clase-categoria");
    const numCat = parseInt(cat.value);
    if(isNaN(numCat) || numCat<=0) {
        return {
            valid: false,
            message: "Numero de categoria invalido"
        };
    }
    
    const numDep = document.getElementById("clase-departamento");
    const numero = parseInt(numDep.value);
    if(numero<=0) {
        return {
            valid: false,
            message: "No se selecciono un Departamento valido"
        };
    }
    if(isEdit===false) {
        return {
            valid: true,
            data: {
                numero_categoria: numCat,
                nombre_clase: nombre,
                numero_departamento: numero
            }
        };
    } else {
        const numCla = parseInt(document.getElementById("clase-numero").value);
        if(isNaN(numCla) || !numCla ) {
            return {
                valid: false,
                message: "El numero es invalido."
            };
        }
        const activo = document.getElementById("clase-activo").checked;
        return {
            valid: true,
            data: {
                numero_categoria: numCat,
                numero_departamento: numero,
                numero_clase: numCla,
                nombre_clase: nombre,
                activo: activo
            }
        };
    }
}
