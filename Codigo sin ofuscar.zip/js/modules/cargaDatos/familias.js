/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {getDataFrom, submitFamilia} from "../../consultasApi.js";
import {updateSelectDepartamento} from "./departamentos.js";
import {updateSelectClases} from "./clases.js";
import {hideLoading, showLoading} from "./cargaDatos.js";
import {formatDate} from "../../Util.js";

// Inicializar formulario de clases
export function initFamiliaForm() {
    const form = document.getElementById("formFamilia");
    const btnGuardar = document.getElementById("btnGuardarFamilia");
    const nombre = document.getElementById("nombre-familia");
    const numCat = document.getElementById("familia-categoria");
    const numDep = document.getElementById("familia-departamento");
    const numCla = document.getElementById("familia-clase");
    const cleanFormFamilia = document.getElementById("cleanFormFamilia");
    
    nombre.addEventListener("input", () => {
        if(numCat.value!=0 && numDep.value!=0 && numCla.value!=0) {
            btnGuardar.disabled = nombre.value.trim().length === 0;
        }
        nombre.value = nombre.value.toUpperCase();
    });
    
    numCat.addEventListener("change", e=>{
        if(numCat.value!=0 && numDep.value!=0 && numCla.value!=0) {
            btnGuardar.disabled = nombre.value.trim().length === 0;
        }
        updateSelectDepartamento(parseInt(numCat.value), "familia-departamento");
        updateSelectClases(0, 0, "familia-clase");
    });
    numDep.addEventListener("change", e=>{
        if(numCat.value!=0 && numDep.value!=0 && numCla.value!=0) {
            btnGuardar.disabled = nombre.value.trim().length === 0;
        }
        updateSelectClases(parseInt(numCat.value), parseInt(numDep.value), "familia-clase");
    });
    numCla.addEventListener("change", e=>{
        if(numCat.value!=0 && numDep.value!=0 && numCla.value!=0) {
            btnGuardar.disabled = nombre.value.trim().length === 0;
        }
    });
    
    cleanFormFamilia.addEventListener("click", ()=>{
        updateSelectDepartamento(0, "familia-departamento");
        updateSelectClases(0, 0, "familia-clase");
        setCreateFamilia();
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const isEdit = btnGuardar.innerText.indexOf("Actualizar")>=0;
        const validation = validateData(isEdit);

        if (!validation.valid) {
            alert(validation.message);
            return;
        }
        showLoading();
        btnGuardar.disabled = true;
        console.log(validation.data);
        
        if(isEdit===false) {
            await submitFamilia("newFamily", validation.data, success=>{
                if(success === true) 
                    form.reset();
                if(numDep.value!=0) {
                    btnGuardar.disabled = nombre.value.trim().length === 0;
                }
                hideLoading();
                setCreateFamilia();
            });
        } else {
            await submitFamilia("updateFamily", validation.data, success=>{
                if(success === true) {
                    form.reset();
                    setCreateFamilia();
                }
                if(numDep.value!=0) {
                    btnGuardar.disabled = nombre.value.trim().length === 0;
                }
                hideLoading();
            });
        }
    });
    
    const select = document.getElementById("familia-clase");
    select.addEventListener("change", e=>{
        try {
            const numCla = e.currentTarget.selectedOptions[0].value;
            numCla = parseInt(numCla);
        } catch(e) {
            console.error(e);
        }
    });
}

export function setCreateFamilia() {
    const btnGuardar = document.getElementById("btnGuardarFamilia");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Crear familia`;
    const panelData = document.getElementById("edit-familia");
    if(panelData.className.indexOf("hidden")===-1)
        panelData.classList.add("hidden");
    btnGuardar.disabled = true;
}
export function setUpdateFamilia(data) {
    const btnGuardar = document.getElementById("btnGuardarFamilia");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Actualizar familia`;
    fillform(data);
    const panelData = document.getElementById("edit-familia");
    if(panelData.className.indexOf("hidden")>=0)
        panelData.classList.remove("hidden");
    btnGuardar.disabled = false;
}

function fillform(data) {
    try {
        showLoading();
        document.getElementById("nombre-familia").value = data.nombre_familia;
        document.getElementById("familia-numero").value = data.numero_familia;
        document.getElementById("familia-activo").checked = data.activo;
        
        document.getElementById("familia-fecha_alta").value = data.fecha_creacion? formatDate(data.fecha_creacion, "AAAA-MM-DD"): "";
        document.getElementById("familia-fecha_baja").value = data.fecha_baja? formatDate(data.fecha_baja, "AAAA-MM-DD"): "";
        
        const numCat = data.numero_categoria;
        const numDep = data.numero_departamento;
        const numCla = data.numero_clase;
        
        updateSelectDepartamento(numCat, "familia-departamento");
        updateSelectClases(numCat, numDep, "familia-clase");
        window.setTimeout(()=>{
            document.getElementById("familia-categoria").value = numCat || 0;
            document.getElementById("familia-departamento").value = numDep || 0;
            document.getElementById("familia-clase").value = numCla || 0;
            hideLoading();
        }, 1000);
    } catch(e) {
        console.error(e);
    }
}

// actualizar lista de clases
export function updateSelectFamilias(numCat, numDep, numCla, divSelect) {
    const select = document.getElementById(divSelect);
    select.innerHTML = "";
    const option = document.createElement("option");
    option.innerHTML = "Seleccionar Familia";
    option.value = 0;
    select.appendChild(option);
    if(!numCat || !numDep || !numCla) {
        select.disabled = true;
        return;
    }
    showLoading();
    getDataFrom("familias", "numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla, data=>{ 
        if(!data) {
            alert("No se encontro informaón de Familias");
            return;
        }
        data = data.data || [];
        data = data.filter(d=>{
            return d.numero_departamento===numDep &&
                    d.numero_clase===numCla;
        });
        if(data.length<=0) {
            hideLoading();
            return;
        }
        
        select.disabled = false;
        data.forEach(dep=>{
            const o = document.createElement("option");
            o.innerHTML = dep.nombre_familia;
            o.value = dep.numero_familia;
            select.appendChild(o);
        });
        hideLoading();
    });
}

function validateData(isEdit) {
    const nombreInput = document.getElementById("nombre-familia");
    const nombre = nombreInput.value.trim();
    if (nombre.length === 0) {
        return {
            valid: false,
            message: "Debes ingresar el nombre de la clase."
        };
    }
    if (nombre.length > 100) {
        return {
            valid: false,
            message: "El nombre no puede superar los 100 caracteres."
        };
    }
    
    const cat = document.getElementById("familia-categoria");
    const numCat = parseInt(cat.value);
    if(isNaN(numCat) || numCat<=0) {
        return {
            valid: false,
            message: "Numero de categoria invalido"
        };
    }
    
    const numDep = document.getElementById("familia-departamento");
    const numeroDep = parseInt(numDep.value);
    if(numeroDep<=0) {
        return {
            valid: false,
            message: "No se selecciono un Departamento valido"
        };
    }
    const numCla = document.getElementById("familia-clase");
    const numeroClase = parseInt(numCla.value);
    if(numeroClase<=0) {
        return {
            valid: false,
            message: "No se selecciono un Departamento valido"
        };
    }
    
    
    if(!isEdit) {
        return {
            valid: true,
            data: {
                nombre_familia: nombre,
                numero_categoria: numCat,
                numero_departamento: numeroDep,
                numero_clase: numeroClase
            }
        };
    } else {
        const numFam = document.getElementById("familia-numero");
        const numeroFam = parseInt(numFam.value);
        if(numeroFam<=0) {
            return {
                valid: false,
                message: "Numero familia invalido"
            };
        }
        const activoInput = document.getElementById("familia-activo");
        const activo = activoInput.checked;
        return {
            valid: true,
            data: {
                nombre_familia: nombre,
                numero_categoria: numCat,
                numero_departamento: numeroDep,
                numero_familia: numeroFam,
                numero_clase: numeroClase,
                activo: activo
            }
        };
    }
}
