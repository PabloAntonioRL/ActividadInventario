/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {getDataFrom, submitInventario, updateInventario} from "../../consultasApi.js";
import {updateSelectDepartamento} from "./departamentos.js";
import {updateSelectFamilias} from "./familias.js";
import {updateSelectClases} from "./clases.js";
import {formatDate} from "../../Util.js";
import {hideLoading, showLoading} from "./cargaDatos.js";

// Inicializar formulario de clases
export function initInventarioForm(query) {
    const form = document.getElementById("formInventario");
    const btnGuardar = document.getElementById("submitItem");
    const numCat = document.getElementById("inventario-categoria");
    const numDep = document.getElementById("inventario-departamento");
    const numCla = document.getElementById("inventario-clase");
    const numFam = document.getElementById("inventario-familia");
    const cleanFormInventario = document.getElementById("cleanFormInventario");
    
    const skuInput = document.getElementById("sku");
    
    skuInput.addEventListener("input", () => {
        let value = skuInput.value;
        if(value.length>=6) {
            skuInput.value = value.slice(0, 6);
        }
    });
    skuInput.addEventListener("change", () => {
        checkButton();
        let value = skuInput.value;
        if(value.length>=6) {
            skuInput.value = value.slice(0, 6);
            getItem(parseInt(skuInput.value));
        }
    });
    
    
    numCat.addEventListener("change", e=>{
        checkButton();
        updateSelectDepartamento(parseInt(numCat.value), "inventario-departamento");
        updateSelectClases(0, 0, "inventario-clase");
        updateSelectFamilias(0, 0, 0, "inventario-familia");
    });
    numDep.addEventListener("change", e=>{
        checkButton();
        updateSelectClases(parseInt(numCat.value), parseInt(numDep.value), "inventario-clase");
        updateSelectFamilias(0, 0, 0, "inventario-familia");
    });
    numCla.addEventListener("change", e=>{
        checkButton();
        updateSelectFamilias(parseInt(numCat.value), parseInt(numDep.value), parseInt(numCla.value), "inventario-familia");
    });
    numFam.addEventListener("change", e=>{
        checkButton();
    });
    
    document.getElementById("articulo").addEventListener("change", checkButton);
    document.getElementById("marca").addEventListener("change", checkButton);
    document.getElementById("modelo").addEventListener("change", checkButton);
    document.getElementById("stock").addEventListener("change", checkButton);
    document.getElementById("cantidad").addEventListener("change", checkButton);
    document.getElementById("descontinuado").addEventListener("change", checkButton);
    
    
    cleanFormInventario.addEventListener("click", ()=>{
        updateSelectDepartamento(0, "inventario-departamento");
        updateSelectClases(0, 0, "inventario-clase");
        updateSelectFamilias(0, 0, 0, "inventario-familia");
        checkButton();
    });

    form.addEventListener("submit", async (event) => {
        event.preventDefault();
        const validation = validateInventario();

        if (!validation.valid) {
            alert(validation.message);
            return;
        }
        btnGuardar.disabled = true;
        console.log(validation.data);
        if(btnGuardar.innerText.indexOf("Registrar")>=0) {
            await submitInventario([validation.data], success=>{
                if(success === true) 
                    form.reset();
                checkButton();
            });
        } else {
            await updateInventario(validation.data, success=>{
                if(success === true) 
                    form.reset();
                checkButton();
            });
        }
    });
    
    const select = document.getElementById("familia-clase");
    select.addEventListener("change", e=>{
        try {
            const numCla = e.currentTarget.selectedOptions[0].value;
            numCla = parseInt(numCla);
        } catch(e) {
            console.error(e);
        }
    });
}

function checkButton() {
    let valid = true;
    let sku = document.getElementById("sku").value;
    sku = parseInt(sku);
    if(isNaN(sku) || sku<10000) valid = false;
    
    let numDep = document.getElementById("inventario-departamento").value;
    if(!numDep) valid = false;
    let numCla = document.getElementById("inventario-clase").value;
    if(!numCla) valid = false;
    let numFam = document.getElementById("inventario-familia").value;
    if(!numFam) valid = false;
    
    const btnGuardar = document.getElementById("submitItem");
    if(valid===true) {
        btnGuardar.disabled = false;
    } else {
        btnGuardar.disabled = true;
    }
}

export function getItem(sku) {
    showLoading();
    getDataFrom("inventario", "sku="+sku, data=>{ 
        console.log(data);
        if(!data) {
            return;
        }
        data = data.data || [];
        if(data.length>0) {
            setFormToUpdate();
            fillForm(data[0]);
        } else {
            const form = document.getElementById("formInventario");
            form.reset();
            const skuInput = document.getElementById("sku").value = sku;
            updateSelectClases(0, 0, "inventario-clase");
            updateSelectFamilias(0, 0, 0, "inventario-familia");
            checkButton();
            setFormToNew();
            hideLoading();
        }
    });
}

function fillForm(item) {
    try {
        if(document.getElementById("sku").value!==item.sku && item.sku!==0);
            document.getElementById("sku").value = item.sku;
        document.getElementById("articulo").value = item.articulo || "";
        document.getElementById("marca").value = item.marca || "";
        document.getElementById("modelo").value = item.modelo || "";
        document.getElementById("descontinuado").checked = item.descontinuado===1;
        document.getElementById("stock").value = item.stock || 0;
        document.getElementById("cantidad").value = item.cantidad || 0;
        
        document.getElementById("fecha_alta").value = item.fecha_alta? formatDate(item.fecha_alta, "AAAA-MM-DD"): "";
        document.getElementById("fecha_baja").value = item.fecha_baja? formatDate(item.fecha_baja, "AAAA-MM-DD"): "";
        
        const numCat = item.numero_categoria;
        const numDep = item.numero_departamento;
        const numCla = item.numero_clase;
        const numFam = item.numero_familia;
        
        updateSelectDepartamento(numCat, "inventario-departamento");
        updateSelectClases(numCat, numDep, "inventario-clase");
        updateSelectFamilias(numCat,numDep, numCla, "inventario-familia");
        window.setTimeout(()=>{
            document.getElementById("inventario-categoria").value = numCat || 0;
            document.getElementById("inventario-departamento").value = numDep || 0;
            document.getElementById("inventario-clase").value = numCla || 0;
            document.getElementById("inventario-familia").value = numFam || 0;
            checkButton();
            hideLoading();
        }, 1000);
        
    } catch(e) {
        console.error(e);
    }
}

function validateInventario() {
    let sku = document.getElementById("sku").value;
    sku = parseInt(sku);
    if(isNaN(sku) || sku<10000) {
        return {valid: false, message: "El SKU es invalido"};
    }
    
    let articulo = document.getElementById("articulo").value;
    if(!articulo) {
        return {valid: false, message: "Falta el nombre del articulo"};
    }
    let marca = document.getElementById("marca").value;
    if(!marca) {
        return {valid: false, message: "Falta el nombre de la marca"};
    }
    let modelo = document.getElementById("modelo").value;
    if(!modelo) {
        return {valid: false, message: "Falta el modelo"};
    }
    let stock = parseInt(document.getElementById("stock").value);
    if(!stock || isNaN(stock)) {
        return {valid: false, message: "Falta el stock"};
    }
    let cantidad = parseInt(document.getElementById("cantidad").value);
    if(!cantidad || isNaN(cantidad)) {
        return {valid: false, message: "Falta la cantidad"};
    }
//    if(cantidad>stock) {
//        return {valid: false, message: "La cantidad no puede ser mayor a stock"};
//    }
    
    const numCat = parseInt(document.getElementById("inventario-categoria").value);
    if(isNaN(numCat) || numCat<=0) {
        return {
            valid: false,
            message: "Numero de categoria invalido"
        };
    }
    
    const numDep = parseInt(document.getElementById("inventario-departamento").value);
    if(!numDep || isNaN(numDep)) {
        return {valid: false, message: "Falta seleccionar un departamento"};
    }
    let numCla = parseInt(document.getElementById("inventario-clase").value);
    if(!numCla || isNaN(numCla)) {
        return {valid: false, message: "Falta la clase"};
    }
    
    let numFam = parseInt(document.getElementById("inventario-familia").value);
    if(!numFam || isNaN(numFam)) {
        return {valid: false, message: "Falta una familia"};
    }
    
    return {valid: true, 
        data: {
            sku: sku,
            articulo: articulo,
            marca: marca,
            modelo: modelo,
            stock: stock,
            cantidad: cantidad,
            numero_categoria: numCat,
            numero_departamento: numDep,
            numero_clase: numCla,
            numero_familia: numFam,
            descontinuado: document.getElementById("descontinuado").checked===true? 1: 0
        }
    };
}


function setFormToUpdate() {
    const btnGuardar = document.getElementById("submitItem");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Actualizar Articulo`;
    const fechas = document.getElementById("inventario-fechas");
    if(fechas.className.indexOf("hidden")>=0)
        fechas.classList.remove("hidden");
}
function setFormToNew() {
    const btnGuardar = document.getElementById("submitItem");
    btnGuardar.innerHTML = `<i class="bi bi-floppy2-fill" aria-hidden="true"></i> Registrar Articulo`;
    const fechas = document.getElementById("inventario-fechas");
    if(fechas.className.indexOf("hidden")===-1)
        fechas.classList.add("hidden");
}