/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {initializeTabs} from "../../tabs.js";
import {initializeCategoriasForm, setUpdateCategoria} from "./categorias.js";
import {initializeDepartamentoForm, setUpdateDepartamento} from "./departamentos.js";
import {initClasesForm, setUpdateClase} from "./clases.js";
import {initFamiliaForm, setUpdateFamilia} from "./familias.js";
import {initInventarioForm, getItem} from "./inventario.js";
import {initModal} from "../../modal.js";
import {obtenerParametrosURL} from "../../Util.js";
import {getDataFrom} from "../../consultasApi.js";

let statusInterval = null;
let loadingNode = null;

export function destroyModule() {
    if (statusInterval) {
        clearInterval(statusInterval);
        statusInterval = null;
    }
}
export  function loadModule() {
    console.log("Cargando modulo Carga de datos");
    
    loadingNode = document.getElementById("loading");
    hideLoading();
    
    const headerTitle = document.getElementById("sectionTitle");
    headerTitle.innerHTML = "Carga de Datos";
    
    
    initFormItem();
    initFormDepartment();
    initFormClass();
    initFormFamily();
    
    
    const nombreDepartamento = document.getElementById("nombre-departamento");
    const btnGuardarDepartamento = document.getElementById("btnGuardarDepartamento");

    nombreDepartamento.addEventListener("input", () => {

        const nombre = nombreDepartamento.value.trim();

        btnGuardarDepartamento.disabled = nombre.length === 0;

    });
    
    initModal();
    initializeCategoriasForm();
    initializeDepartamentoForm();
    initClasesForm();
    initFamiliaForm();
    initInventarioForm();
    
    const query = obtenerParametrosURL();
    let selectedTab;
    if(Object.keys(query).length > 0) {
        setEditForm(query);
        selectedTab = query.tipo || "";
    }
    
    document.querySelectorAll(".tabs-container").forEach(container => {
        initializeTabs(container, selectedTab);
    });
}

function initFormCategory() {
    try {
        const nomDep = document.getElementById("nombre-departamento");
        nomDep.value = "";
    } catch(e) {
        console.error(e);
    }
}
function initFormDepartment() {
    try {
        const nomDep = document.getElementById("nombre-departamento");
        nomDep.value = "";
    } catch(e) {
        console.error(e);
    }
}
function initFormClass() {
    try {
        const numDep = document.getElementById("clase-departamento");
        numDep.value = "";
        const nombre = document.getElementById("nombre-clase");
        nombre.value = "";
    } catch(e) {
        console.error(e);
    }
}
function initFormFamily() {
    try {
        const numDep = document.getElementById("familia-departamento");
        numDep.value = "";
        const numCla = document.getElementById("familia-clase");
        numCla.value = "";
        const nombre = document.getElementById("nombre-familia");
        nombre.value = "";
    } catch(e) {
        console.error(e);
    }
}

function initFormItem() {
    try {
        const sku = document.getElementById("sku");
        sku.value = "";
        const articulo = document.getElementById("articulo");
        articulo.value = "";
        const marca = document.getElementById("marca");
        marca.value = "";
        const stock = document.getElementById("stock");
        stock.value = "";
        const cantidad = document.getElementById("cantidad");
        cantidad.value = "";
        const numDep = document.getElementById("inventario-departamento");
        numDep.value = "0";
        const numCla = document.getElementById("inventario-clase");
        numCla.value = "0";
        const numFam = document.getElementById("inventario-familia");
        numFam.value = "0";
        const descontinuado = document.getElementById("descontinuado");
        descontinuado.value = "";
    } catch(e) {
        console.error(e);
    }
}


export function hideLoading() {
    if(loadingNode.className.indexOf("hidden")===-1)
        loadingNode.classList.add("hidden");
}
export function showLoading() {
    if(loadingNode.className.indexOf("hidden")>=0) 
        loadingNode.classList.remove("hidden");
}


function setEditForm(query) {
    let numCat, numDep, numCla, numFam;
    switch(query.tipo) {
        case "inventario":
            const sku = query.sku || 0;
            if(isNaN(sku) || sku<10000) {
                alert("El Sku no es valido");
                return;
            }
            getItem(sku);
            break;
        case "categoria":
            numCat = query.numero_categoria;
            getDataFrom("categorias", "numero_categoria="+numCat, data=>{
                if(!data) {
                    console.error("No se encontro la categoria");
                }
                data = data.data || [];
                setUpdateCategoria(data[0]);
            });
            break;
        case "departamento":
            numCat = query.numero_categoria;
            numDep = query.numero_departamento;
            getDataFrom("departamentos", "numero_categoria="+numCat+"&numero_departamento="+numDep, data=>{
                if(!data) {
                    console.error("No se encontro el departamento");
                }
                data = data.data || [];
                setUpdateDepartamento(data[0]);
            });
            break;
        case "clase":
            numCat = query.numero_categoria;
            numDep = query.numero_departamento;
            numCla = query.numero_clase;
            getDataFrom("clases", "numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla, data=>{
                if(!data) {
                    console.error("No se encontro la clase");
                }
                data = data.data || [];
                setUpdateClase(data[0]);
            });
            break;
        case "familia":
            numCat = query.numero_categoria;
            numDep = query.numero_departamento;
            numCla = query.numero_clase;
            numFam = query.numero_familia;
            getDataFrom("familias", "numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla+"&numero_familia="+numFam, data=>{
                if(!data) {
                    console.error("No se encontro la familia");
                }
                data = data.data || [];
                setUpdateFamilia(data[0]);
            });
            break;
    }
}