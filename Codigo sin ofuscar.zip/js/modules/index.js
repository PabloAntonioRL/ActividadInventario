/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */


export const modules = [
    
    {
        id: 'consultas',
        title: 'Consultas',
        load: () => import('./consultas')
    },{
        id: 'cargaDatos',
        title: 'Carga de Datos',
        load: () => import('./cargaDatos')
    }
];