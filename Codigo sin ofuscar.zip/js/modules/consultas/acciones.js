/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {navigate} from "../../router.js";
import {showModal, createErrorPanel, createSuccessPanel, createWarningPanel} from "../../modal.js";
import {submitEliminar, submitReactivar} from "../../consultasApi.js";
import {showLoading, hideLoading, updateTable} from "./consultas.js";

export function editarElemento(data) {

    console.log("Registro seleccionado:", data);
    let params = null;
    if(data.sku) {
        params = new URLSearchParams({
            tipo: "inventario",
            sku: data.sku
        });
    } else if(data.numero_familia) {
        params = new URLSearchParams({
            tipo: "familia",
            numero_categoria: data.numero_categoria,
            numero_departamento: data.numero_departamento,
            numero_clase: data.numero_clase,
            numero_familia: data.numero_familia,
            nombre_familia: data.nombre_familia
        });
    } else if(data.numero_clase) {
        params = new URLSearchParams({
            tipo: "clase",
            numero_categoria: data.numero_categoria,
            numero_departamento: data.numero_departamento,
            numero_clase: data.numero_clase,
            nombre_clase: data.nombre_clase
        });
    } else if(data.numero_departamento) {
        params = new URLSearchParams({
            tipo: "departamento",
            numero_categoria: data.numero_categoria,
            numero_departamento: data.numero_departamento,
            nombre_departamento: data.nombre_departamento
        });
    } else if(data.numero_categoria) {
        params = new URLSearchParams({
            tipo: "categoria",
            numero_categoria: data.numero_categoria,
            nombre_categoria: data.nombre_categoria
        });
    }
    if(params!==null)
        navigate(`cargaDatos?${params.toString()}`);
}

export function reactivarElemento(data) {
    console.log(data);
    let selected, id, endpoint;
    let msg = "";
    if(data.sku) {
        selected = "inventario";
        id = parseInt(data.sku);
        if(isNaN(id) || !id || id<100000) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "from=inventario&sku="+id;
    } else if(data.numero_familia) {
        selected = "familia";
        const numFam = parseInt(data.numero_familia);
        if(isNaN(numFam) || !numFam || numFam<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCla = parseInt(data.numero_clase);
        if(isNaN(numCla) || !numCla || numCla<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numDep = parseInt(data.numero_departamento);
        if(isNaN(numDep) || !numDep || numDep<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "from=familias&numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla+"&numero_familia="+numFam;
    } else if(data.numero_clase) {
        selected = "clase";
        const numCla = parseInt(data.numero_clase);
        if(isNaN(numCla) || !numCla || numCla<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numDep = parseInt(data.numero_departamento);
        if(isNaN(numDep) || !numDep || numDep<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "from=clases&numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla;
    } else if(data.numero_departamento) {
        selected = "departamento";
        const numDep = parseInt(data.numero_departamento);
        if(isNaN(numDep) || !numDep || numDep<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "from=departamentos&numero_categoria="+numCat+"&numero_departamento="+numDep;
    } else if(data.numero_categoria) {
        selected = "categoria";
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "from=categorias&numero_categoria="+numCat;
    }
    
    if(!selected || !id) return;
    showModal(createWarningPanel("Se va a reactivar el siguiente elemento.", data,
        response =>{
            if(response===true) {
                // eliminar elemento
                console.log("Se eliminara el registo "+id+" "+selected);
                //return;
                showLoading();
                submitReactivar(id, response=>{
                    updateTable(selected);
                    hideLoading();
                });
            } else {
                // no se hace nada mas
                console.log("No se activa el registro");
            }
        }
    ));
}

// al intentar eliminar un elemento este es marcado como "inactivo" y no es eliminado de la base de datos
// despues de que un elemento esta "inactivo" es cuando el elemento realmente puede ser eliminado de la base de datos
// pero si el elemento es un padre de algun otro elemento, por ejemplo, si intentas eliminar una familia, la cual tiene algun articulo registraro
// la familia no podra ser eliminada hasta que todos los articulos que pertenescan a esta sean eliminados anteriormente
// despues de que un elemento esta como "inactivo" todos los elementos relacionado a este seran ocultados, y apareceran como "inactivos"
export function eliminarElemento(data, trueDelete) {
    console.log(data);
    let selected, id, endpoint;
    let msg = "";
    // la variable "trueDelete" determina si el elemento se intentara eliminar de verdad o solo desactivar
    if(data.sku) {
        selected = "inventario";
        endpoint = "deleteItem";
        id = parseInt(data.sku);
        if(isNaN(id) || !id || id<100000) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "sku="+id;
    } else if(data.numero_familia) {
        selected = "familia";
        endpoint = "deleteFamily";
        const numFam = parseInt(data.numero_familia);
        if(isNaN(numFam) || !numFam || numFam<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCla = parseInt(data.numero_clase);
        if(isNaN(numCla) || !numCla || numCla<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numDep = parseInt(data.numero_departamento);
        if(isNaN(numDep) || !numDep || numDep<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla+"&numero_familia="+numFam+(trueDelete===true? "&trueDelete=true": "");
    } else if(data.numero_clase) {
        selected = "clase";
        endpoint = "deleteClass";
        const numCla = parseInt(data.numero_clase);
        if(isNaN(numCla) || !numCla || numCla<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numDep = parseInt(data.numero_departamento);
        if(isNaN(numDep) || !numDep || numDep<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla+(trueDelete===true? "&trueDelete=true": "");
    } else if(data.numero_departamento) {
        selected = "departamento";
        endpoint = "deleteDepartment";
        const numDep = parseInt(data.numero_departamento);
        if(isNaN(numDep) || !numDep || numDep<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "numero_categoria="+numCat+"&numero_departamento="+numDep+(trueDelete===true? "&trueDelete=true": "");
    } else if(data.numero_categoria) {
        selected = "categoria";
        endpoint = "deleteCategory";
        const numCat = parseInt(data.numero_categoria);
        if(isNaN(numCat) || !numCat || numCat<0) {
            console.log("No se selecciono un elemento valido");
            return;
        }
        id = "numero_categoria="+numCat+(trueDelete===true? "&trueDelete=true": "");
    }
    
    if(!selected || !id || !endpoint) return;
    showModal(createWarningPanel("Esta seguro de que desea eliminar el registro.", data,
        response =>{
            if(response===true) {
                // eliminar elemento
                console.log("Se eliminara el registo "+id+" "+endpoint+" "+selected);
                //return;
                showLoading();
                submitEliminar(endpoint, id, response=>{
                    updateTable(selected);
                    hideLoading();
                });
            } else {
                // no se hace nada mas
                console.log("No se elimina el registro");
            }
        }
    ));
}
