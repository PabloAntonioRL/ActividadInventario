/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */

import {loadModule, destroyModule} from "./consultas.js";
import {fetchModuleHtml} from "../../router.js";

export default {
    id: 'consultas',
    title: 'Consultas',

    async mount(container) {
        const html = await fetchModuleHtml("consultas", "consultas.html")
            .then(r => r.text());

        container.innerHTML = html;
        loadModule();
    },

    unmount() {
        destroyModule();
    }
};
