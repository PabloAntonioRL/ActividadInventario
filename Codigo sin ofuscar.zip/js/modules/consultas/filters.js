/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {getActualData} from "./consultas.js";
import {createTable} from "./tableManager.js";
import {normalizarTexto} from "../../Util.js";

let filterData = null;

export function setFilters(container) {
    const tabls = container.querySelectorAll("[data-tab-content]");
    tabls.forEach(content=>{
        const selected = content.dataset.tabContent;
        const inputs = content.querySelectorAll("input, select");
        inputs.forEach(input=>{
            input.addEventListener("input", e=>{
                aplyFilter(inputs, selected);
            });
        });
    });

}
function aplyFilter(inputs, selected) {
    filterData = getActualData();
    console.log("Aplicando filtro a "+filterData.length+" datos");
    inputs.forEach(input=>{
        let value = input.value;
        if(!value || value=="0") return;
        value = normalizarTexto(value);
        const key = input.name;
        filterData = filterData.filter(d=>{
            if(!d[key]) return false;
            return normalizarTexto(d[key]).indexOf(value)>=0;
        });
    });
    
    let idTable;
    switch(selected){
        case "categorias": idTable = "tabla-categorias"; break;
        case "inventario": idTable = "tabla-inventario"; break;
        case "departamento": idTable = "tabla-departamentos"; break;
        case "clase": idTable = "tabla-clases"; break;
        case "familia": idTable = "tabla-familias"; break;
    }
    
    const container = document.getElementById(idTable);
    createTable(filterData,[ "numero_categoria", "nombre_categoria",
        "numero_departamento","nombre_departamento",
        "numero_clase","nombre_clase","numero_familia",
        "nombre_familia","sku","descontinuado","articulo"
    ], container);
}

export function getFilterData() {
    return filterData;
}

export function resetData() {
    filterData = null;
}
