/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {editarElemento, eliminarElemento, reactivarElemento} from "./acciones.js";
import {formatDate} from "../../Util.js";

export function createTable(data = [], columnOrder = [], container = null, isDiactivate = false) {
     container.innerHTML = "";
    if (!Array.isArray(data) || data.length === 0) {
        console.warn("No se encontraron datos para la tabla");

        if (container) container.innerHTML = "No se encontraron datos para la tabla";

        return "";
    }
    data = orderData(data);
    // Obtener todas las propiedades disponibles
    const columns = [...new Set(data.flatMap(item => Object.keys(item)))];

    // Aplicar orden personalizado
    const orderedColumns = [
        ...new Set(columnOrder.filter(column => columns.includes(column))),
        ...columns.filter(column => !columnOrder.includes(column))
    ];

    // Formatear encabezados
    const formatHeader = (key) => {
        return key
            .replace(/_/g, " ")
            .replace(/\b\w/g, letter => letter.toUpperCase());
    };

    // Escapar contenido HTML
    const escapeHTML = (value) => {
        return String(value)
            .replace(/&/g, "&amp;")
            .replace(/</g, "&lt;")
            .replace(/>/g, "&gt;")
            .replace(/"/g, "&quot;")
            .replace(/'/g, "&#039;");
    };

    // Formatear valores
    const formatValue = (value, column) => {

        if (value === null || value === undefined || value === "")
            return "—";

        if (typeof value === "boolean")
            return value ? "Sí" : "No";

        if (typeof value === "object")
            return escapeHTML(JSON.stringify(value));

        if (column.includes("fecha"))
            return escapeHTML(formatDate(value));

        return escapeHTML(value);
    };

    // Encabezados
    const headers = `
        <th class="action-header"></th>
    ` + orderedColumns.map(column => `
        <th>${escapeHTML(formatHeader(column))}</th>
    `).join("");
        

    const rows = data.map(item => {
        let type;

        if(item.sku) type = "inventario";
        else if(item.nombre_familia) type = "familia";
        else if(item.nombre_clase) type = "clase";
        else if(item.nombre_departamento) type = "departamento";

        return `
            <tr>
                <td class="action-cell">

                    <button
                        type="button"
                        class="table-action-button"
                        data-action="toggle"
                        aria-label="Mostrar acciones"
                        title="Más opciones"
                    >
                        <i class="bi bi-three-dots-vertical"></i>
                    </button>

                    <div class="table-action-menu" hidden>

                        ${type==="inventario"?(`
                            <button type="button" data-action="edit">
                                <i class="bi bi-pencil"></i>
                                Editar
                            </button>
                            <button type="button" data-action="delete">
                                <i class="bi bi-x-lg"></i>
                                Eliminar
                            </button>`):
                            (item.activo===false? `
                                <button type="button" data-action="activate">
                                    <i class="bi bi-power"></i>
                                    Reactivar
                                </button>
                                <button type="button" data-action="delete">
                                    <i class="bi bi-x-lg"></i>
                                    Eliminar
                                </button>`: (
                                isDiactivate===true? `
                                    <button type="button" data-action="delete">
                                        <i class="bi bi-x-lg"></i>
                                        Eliminar
                                    </button>
                                    <button type="button" data-action="diactivate">
                                        <i class="bi bi-trash"></i>
                                        Desactivar
                                    </button>`:
                                    `<button type="button" data-action="edit">
                                        <i class="bi bi-pencil"></i>
                                        Editar
                                    </button>
                                    <button type="button" data-action="diactivate">
                                        <i class="bi bi-trash"></i>
                                        Desactivar
                                    </button>`
                                )
                            )
                        }

                    </div>

                    <span hidden data-row="${escapeHTML(JSON.stringify(item))}"></span>

                </td>

                ${orderedColumns.map(column => `
                    <td>${formatValue(item[column], column)}</td>
                `).join("")}

            </tr>
        `;
    }).join("");    

    // Construir tabla
    const html = `
        <div class="table-container">
            <table class="custom-table">

                <thead>
                    <tr>${headers}</tr>
                </thead>

                <tbody>
                    ${rows}
                </tbody>

            </table>
        </div>
    `;

    // Si se proporciona un contenedor, insertar la tabla
    if (container) {

        container.innerHTML = html;

        // Registrar eventos solamente una vez
        if (!container.dataset.tableEventsInitialized) {

            container.addEventListener("click", (event) => {

                const button = event.target.closest("[data-action]");

                if (!button || !container.contains(button)) return;

                const action = button.dataset.action;
                const cell = button.closest(".action-cell");

                if (!cell) return;

                const row = cell.querySelector("[data-row]");

                if (!row) return;

                let data;

                try {
                    data = JSON.parse(row.dataset.row);
                } catch (error) {
                    console.error("Error al obtener los datos de la fila:", error);
                    return;
                }

                const menu = cell.querySelector(".table-action-menu");

                switch (action) {

                    
                    case "toggle": {

                        const menu = button._actionMenu ||
                                     cell.querySelector(".table-action-menu");

                        if (!menu) break;

                        // Guardar los datos de la fila
                        menu.dataset.row = row.dataset.row;

                        // Cerrar otros menús
                        document.querySelectorAll(".table-action-menu.is-portal")
                            .forEach(item => {
                                item.hidden = true;
                            });

                        // Si ya estaba abierto, cerrarlo
                        if (button._menuOpen) {
                            menu.hidden = true;
                            button._menuOpen = false;
                            break;
                        }

                        // Trasladar el menú al body
                        if (!menu.classList.contains("is-portal")) {
                            menu.classList.add("is-portal");
                            document.body.appendChild(menu);
                            button._actionMenu = menu;
                        }

                        menu.hidden = false;
                        button._menuOpen = true;

                        // Posición del botón
                        const buttonRect = button.getBoundingClientRect();

                        // Dimensiones del menú
                        const menuRect = menu.getBoundingClientRect();

                        const margin = 8;

                        // Posición horizontal
                        let left = buttonRect.left;

                        if (left + menuRect.width > window.innerWidth - margin) {
                            left = window.innerWidth - menuRect.width - margin;
                        }

                        left = Math.max(margin, left);

                        // Posición vertical
                        let top = buttonRect.bottom + 5;

                        if (top + menuRect.height > window.innerHeight - margin) {
                            top = buttonRect.top - menuRect.height - 5;
                        }

                        top = Math.max(margin, top);

                        // Aplicar posición
                        menu.style.position = "fixed";
                        menu.style.left = `${left}px`;
                        menu.style.top = `${top}px`;
                        menu.style.right = "auto";
                        menu.style.bottom = "auto";
                        menu.style.zIndex = "20000";

                        break;
                    }

                    
                    
                    case "activate":
                        menu.hidden = true;
                        reactivarElemento(data);
                        break;
                        
                    case "edit":
                        menu.hidden = true;
                        editarElemento(data);
                        break;

                    case "diactivate":
                        menu.hidden = true;
                        eliminarElemento(data);
                        break;
                        
                    case "delete":
                        menu.hidden = true;
                        eliminarElemento(data, true);
                        break;
                }

            });

            container.dataset.tableEventsInitialized = "true";
        }
        if (!document.documentElement.dataset.menuEventsInitialized) {

            document.addEventListener("click", (event) => {

                const option = event.target.closest(
                    ".table-action-menu [data-action]"
                );

                // Cerrar si se hace clic fuera del menú y del botón
                if (!option) {
                    if (!event.target.closest(".table-action-button")) {
                        document.querySelectorAll(
                            ".table-action-menu.is-portal"
                        ).forEach(menu => {
                            menu.hidden = true;

                            // Actualizar el estado del botón
                            document.querySelectorAll(".table-action-button")
                                .forEach(button => {
                                    if (button._actionMenu === menu) {
                                        button._menuOpen = false;
                                    }
                                });
                        });
                    }

                    return;
                }

                const menu = option.closest(".table-action-menu");

                let data;

                try {
                    data = JSON.parse(menu.dataset.row);
                } catch (error) {
                    console.error("Error al obtener los datos:", error);
                    return;
                }

                menu.hidden = true;

                document.querySelectorAll(".table-action-button")
                    .forEach(button => {
                        if (button._actionMenu === menu) {
                            button._menuOpen = false;
                        }
                    });

                switch (option.dataset.action) {

                    case "activate":
                        reactivarElemento(data);
                        break;

                    case "edit":
                        editarElemento(data);
                        break;

                    case "diactivate":
                        eliminarElemento(data);
                        break;

                    case "delete":
                        eliminarElemento(data, true);
                        break;
                }

            });
            
            window.addEventListener("scroll", () => {

                document.querySelectorAll(".table-action-menu.is-portal")
                    .forEach(menu => {
                        menu.hidden = true;

                        document.querySelectorAll(".table-action-button")
                            .forEach(button => {
                                if (button._actionMenu === menu) {
                                    button._menuOpen = false;
                                }
                            });
                    });

            }, true);
            document.documentElement.dataset.menuEventsInitialized = "true";
        }
    }

    return html;
}

function orderData(data) {
    if(!data) return data;
    if(!data.length) return data;
    return data.sort((a, b)=>{
        if(a.sku >0 && b.sku>0) {
            return a.sku<b.sku?-1: 
                    (a.sku>b.sku? 1: 0);
        } else if(a.numero_familia>0 && b.numero_familia>0) {
            return a.numero_familia<b.numero_familia?-1: 
                    (a.numero_familia>b.numero_familia? 1: 0);
        } else if(a.numero_clase>0 && b.numero_clase>0) {
            return a.numero_clase<b.numero_clase?-1: 
                    (a.numero_clase>b.numero_clase? 1: 0);
        } else {
            return a.numero_departamento<b.numero_departamento?-1: 
                    (a.numero_departamento>b.numero_departamento? 1: 0);
        }
    });
}


export function downloadCSV(data, columnOrder = [], filename = "consulta.csv") {
    data = data || [];
    if (!Array.isArray(data) || data.length === 0) {
        alert("No hay información para descargar");
        return;
    }

    const columns = [...new Set(data.flatMap(item => Object.keys(item)))];
    const orderedColumns = [
        ...new Set(columnOrder.filter(column => columns.includes(column))),
        ...columns.filter(column => !columnOrder.includes(column))
    ];

    // Escapar valores para formato CSV
    const escapeCSV = (value) => {
        if (value === null || value === undefined) {
            return "";
        }
        switch(typeof value) {
            default:
                let text = String(value);
                if (/^[\s]*[=+\-@\t\r]/.test(text)) {
                    text = "'" + text;
                }
                return `"${text.replace(/"/g, '""')}"`;
            case "number":
                return value;
        }
        
    };

    const headers = orderedColumns
        .map(column => escapeCSV(column))
        .join(",");
    const rows = data.map(item =>
        orderedColumns
            .map(column => escapeCSV(item[column]))
            .join(",")
    );

    // Crear contenido CSV con BOM para compatibilidad con Excel
    const csvContent = "\uFEFF" + [headers, ...rows].join("\r\n");
    const blob = new Blob([csvContent], {
        type: "text/csv;charset=utf-8;"
    });

    const url = URL.createObjectURL(blob);
    const link = document.createElement("a");
    link.href = url;
    link.download = filename;

    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);

    URL.revokeObjectURL(url);
}


