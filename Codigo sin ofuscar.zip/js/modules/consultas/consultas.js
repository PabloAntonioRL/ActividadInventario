/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {initializeTabs} from "../../tabs.js";
import {initModal} from "../../modal.js";
import {obtenerParametrosURL, formatDate} from "../../Util.js";
import {createTable, downloadCSV} from "./tableManager.js";
import {setFilters, getFilterData, resetData} from "./filters.js";

import {getDataFrom, getInactiveFrom} from "../../consultasApi.js";

let statusInterval = null;
let loadingNode = null;
let actualData = null, inactiveData = null;

export function destroyModule() {
    if (statusInterval) {
        clearInterval(statusInterval);
        statusInterval = null;
    }
}
export  function loadModule() {
    console.log("Cargando modulo Consultas");
    const headerTitle = document.getElementById("sectionTitle");
    headerTitle.innerHTML = "Consulta de Datos";
    
    
    loadingNode = document.getElementById("loading");
    hideLoading();
    
    const query = obtenerParametrosURL();
    let selectedTab;
    if(Object.keys(query).length > 0) {
        selectedTab = query.tipo || "";
    }
    
    document.querySelectorAll(".tabs-container").forEach(container => {
        initializeTabs(container, selectedTab);
        updateTable(selectedTab);
        const tabs = container.querySelectorAll("[data-tab]");
        tabs.forEach(tab => {
            tab.addEventListener("click", e => {
                updateTable(e.currentTarget.dataset.tab);
            });
        });
    });
    
    
    initModal();
    initializeClearButtons(document.getElementById("tabsContainer"));
    setFilters(document.getElementById("tabsContainer"));
    
    const btnDInv = document.getElementById("download-inventario");
    btnDInv.addEventListener("click", ()=>{
        let filterData = getFilterData() || actualData;
        if(filterData) {
            downloadCSV(filterData, [ "numero_categoria",
                    "numero_departamento","nombre_departamento",
                    "numero_clase","nombre_clase","numero_familia",
                    "nombre_familia","sku","descontinuado","articulo"
                ], "inventario_"+formatDate(new Date(), "DD-MM-AAAA"));
        }
    });
    const btnDCat = document.getElementById("download-categorias");
    btnDCat.addEventListener("click", ()=>{
        let filterData = getFilterData() || actualData;
        if(filterData) {
            downloadCSV(filterData, ["numero_categoria",
                    "numero_departamento","nombre_departamento","activo"
                ], "categorias_"+formatDate(new Date(), "DD-MM-AAAA"));
        }
    });
    const btnDDep = document.getElementById("download-departamentos");
    btnDDep.addEventListener("click", ()=>{
        let filterData = getFilterData() || actualData;
        if(filterData) {
            downloadCSV(filterData, ["numero_categoria",
                    "numero_departamento","nombre_departamento","activo"
                ], "departamentos_"+formatDate(new Date(), "DD-MM-AAAA"));
        }
    });
    const btnDCla = document.getElementById("download-clases");
    btnDCla.addEventListener("click", ()=>{
        let filterData = getFilterData() || actualData;
        if(filterData) {
            downloadCSV(filterData, ["numero_categoria",
                    "numero_departamento","nombre_departamento",
                    "numero_clase","nombre_clase","activo"
                ], "clases_"+formatDate(new Date(), "DD-MM-AAAA"));
        }
    });
    const btnDFam = document.getElementById("download-familias");
    btnDFam.addEventListener("click", ()=>{
        let filterData = getFilterData() || actualData;
        if(filterData) {
            downloadCSV(filterData, ["numero_categoria",
                    "numero_departamento","nombre_departamento",
                    "numero_clase","nombre_clase","numero_familia",
                    "nombre_familia","activo"
                ], "familias_"+formatDate(new Date(), "DD-MM-AAAA"));
        }
    });
    
    
    updateSelectCategorias();
    
    const numCat = document.getElementById("inventario-categoria");
    numCat.addEventListener("change", e=>{
        updateSelectDepartamento(parseInt(numCat.value), "inventario-departamento");
        updateSelectClases(parseInt(numCat.value), parseInt(numDep.value), "inventario-clase");
        updateSelectFamilias(0, 0, 0, "inventario-familia");
    });
    const numDep = document.getElementById("inventario-departamento");
    const numCla = document.getElementById("inventario-clase");
    numDep.addEventListener("change", e=>{
        updateSelectClases(parseInt(numCat.value), parseInt(numDep.value), "inventario-clase");
        updateSelectFamilias(0, 0, 0, "inventario-familia");
    });
    numCla.addEventListener("change", e=>{
        updateSelectFamilias(parseInt(numCat.value), parseInt(numDep.value), parseInt(numCla.value), "inventario-familia");
    });
    const numFamDep = document.getElementById("familia-departamento");
    const numFamCla = document.getElementById("familia-clase");
    numFamDep.addEventListener("change", e=>{
        updateSelectClases(parseInt(numCat.value), parseInt(numFamDep.value), "familia-clase");
        //updateSelectFamilias(0, 0, "inventario-familia");
    });
    
    
    // controles para tabla de eleemntos desactivados
    //const tableDiCa = document.getElementById("diactivate-categoria");
    const tableAcCa = document.getElementById("tabla-categorias");
    const showDiCa = document.getElementById("showDiactivate-categorias");
    showDiCa.addEventListener("click", ()=>{
        if(showDiCa.innerHTML.indexOf("Desactivados")>=0) {
            showDiCa.innerText = "Ver Activos";
        } else {
            showDiCa.innerText = "Ver Desactivados";
        }
        updateTable("categoria");
    });
    //const tableDiD = document.getElementById("diactivate-departamentos");
    const tableAcD = document.getElementById("tabla-departamentos");
    const showDiD = document.getElementById("showDiactivate-departamentos");
    showDiD.addEventListener("click", ()=>{
        if(showDiD.innerHTML.indexOf("Desactivados")>=0) {
            showDiD.innerText = "Ver Activos";
        } else {
            showDiD.innerText = "Ver Desactivados";
        }
        updateTable("departamento");
    });
    //const tableDiC = document.getElementById("diactivate-clases");
    const tableAcC = document.getElementById("tabla-clases");
    const showDiC = document.getElementById("showDiactivate-clases");
    showDiC.addEventListener("click", ()=>{
        if(showDiC.innerHTML.indexOf("Desactivados")>=0) {
            showDiC.innerText = "Ver Activos";
        } else {
            showDiC.innerText = "Ver Desactivados";
        }
        updateTable("clase");
    });
    //const tableDi = document.getElementById("diactivate-familias");
    const tableAc = document.getElementById("tabla-familias");
    const showDi = document.getElementById("showDiactivate-familias");
    showDi.addEventListener("click", ()=>{
        if(showDi.innerHTML.indexOf("Desactivados")>=0) {
            showDi.innerText = "Ver Activos";
        } else {
            showDi.innerText = "Ver Desactivados";
        }
        updateTable("familia");
    });
    //const tableDiI = document.getElementById("diactivate-inventario");
    const tableAcI = document.getElementById("tabla-inventario");
    const showDiI = document.getElementById("showDiactivate-inventario");
    showDiI.addEventListener("click", ()=>{
        if(showDiI.innerHTML.indexOf("Desactivados")>=0) {
            showDiI.innerText = "Ver Activos";
        } else {
            showDiI.innerText = "Ver Desactivados";
        }
        updateTable("inventario");
    });
}

export function getActualData() {
    return actualData;
}

export function updateTable(name) {
    showLoading();
    resetData();
    let getData = null, showDi;
    switch(name) {
        default:
        case "inventario":
            showDi = document.getElementById("showDiactivate-inventario");
            getData = showDi.innerText.indexOf("Desactivados")>=0? getDataFrom: getInactiveFrom;
            getData("inventario", null, response=>{
                const container = document.getElementById("tabla-inventario");
                createTable(response?.data,[ "numero_categoria",
                    "numero_departamento","nombre_departamento",
                    "numero_clase","nombre_clase","numero_familia",
                    "nombre_familia","sku","descontinuado","articulo"
                ], container);
                actualData = response?.data || [];
                hideLoading();
            });
            break;
        case "categoria":
            showDi = document.getElementById("showDiactivate-categorias");
            getData = showDi.innerText.indexOf("Desactivados")>=0? getDataFrom: getInactiveFrom;
            getData("categorias", null, response=>{
                const container = document.getElementById("tabla-categorias");
                createTable(response?.data, [
                    "numero_categoria","nombre_categoria","activo"
                ], container);
                actualData = response?.data || [];
                hideLoading();
            });
            break;
        case "departamento":
            showDi = document.getElementById("showDiactivate-departamentos");
            getData = showDi.innerText.indexOf("Desactivados")>=0? getDataFrom: getInactiveFrom;
            getData("departamentos", null, response=>{
                const container = document.getElementById("tabla-departamentos");
                createTable(response?.data, [ "numero_categoria",
                    "numero_departamento","nombre_departamento","activo"
                ], container);
                actualData = response?.data || [];
                hideLoading();
            });
            break;
        case "clase":
            showDi = document.getElementById("showDiactivate-clases");
            getData = showDi.innerText.indexOf("Desactivados")>=0? getDataFrom: getInactiveFrom;
            getData("clases", null, response=>{
                const container = document.getElementById("tabla-clases");
                createTable(response?.data, ["numero_categoria",
                    "numero_departamento","nombre_departamento",
                    "numero_clase","nombre_clase","activo"
                ], container);
                actualData = response?.data || [];
                hideLoading();
            });
            break;
        case "familia":
            showDi = document.getElementById("showDiactivate-familias");
            getData = showDi.innerText.indexOf("Desactivados")>=0? getDataFrom: getInactiveFrom;
            getData("familias", null, response=>{
                const container = document.getElementById("tabla-familias");
                createTable(response?.data,[ "numero_categoria",
                    "numero_departamento","nombre_departamento",
                    "numero_clase","nombre_clase","numero_familia",
                    "nombre_familia","activo"
                ], container);
                actualData = response?.data || [];
                hideLoading();
            });
            break;
    }
}

export function initializeClearButtons(container) {
    container.addEventListener("click", (event) => {
        const button = event.target.closest("button");
        if (!button || !container.contains(button)) return;
        // Identificar el botón de limpiar
        if (button.textContent.trim().toLowerCase() !== "limpiar") {
            return;
        }
        // Buscar la pestaña a la que pertenece
        const tab = button.closest("[data-tab-content]");
        if (!tab) return;
        // Limpiar únicamente sus inputs
        const inputs = tab.querySelectorAll(
            "input, select"
        );

        inputs.forEach(input => {
            if (input.type === "select" ) {
                input.value = "0";
            } else {
                input.value = input.defaultValue;
            }
            input.dispatchEvent(new Event("input", { bubbles: true }));
            input.dispatchEvent(new Event("change", { bubbles: true }));
        });
    });
}


export function hideLoading() {
    if(loadingNode.className.indexOf("hidden")===-1)
        loadingNode.classList.add("hidden");
}
export function showLoading() {
    if(loadingNode.className.indexOf("hidden")>=0) 
        loadingNode.classList.remove("hidden");
}

export function updateSelectCategorias() {
    showLoading();
    getDataFrom("categorias", null, data=> { 
        if(!data) {
            alert("No se encontro informaón de Departamentos");
            return;
        }
        data = data.data || [];
        const divs = ["departamento-categoria", "clase-categoria", 
            "familia-categoria", "inventario-categoria"];
        divs.forEach(id=> {
            const select = document.getElementById(id);
            if(!select) return;
            select.innerHTML = "";
            select.disabled = false;
            const option = document.createElement("option");
            option.innerHTML = "Seleccionar Categoria";
            option.value = 0;
            select.appendChild(option);
            
            data.forEach(dep=>{
                const o = document.createElement("option");
                o.innerHTML = dep.nombre_categoria;
                o.value = dep.numero_categoria;
                select.appendChild(o);
            });
        });
        hideLoading();
    });
}
export function updateSelectDepartamento(numCat, divId) {
    const select = document.getElementById(divId);
    select.innerHTML = "";
    const option = document.createElement("option");
    option.innerHTML = "Seleccionar Departamento";
    option.value = 0;
    select.appendChild(option);
    if(!numCat) {
        select.disabled = true;
        return;
    }
    showLoading();
    getDataFrom("departamentos", "numero_categoria="+numCat, data=>{ 
        if(!data) {
            alert("No se encontro informaón de Departamentos");
            return;
        }
        data = data.data || [];
        if(data<=0) return;
        
        select.disabled = false;
        data.forEach(dep=>{
            const o = document.createElement("option");
            o.innerHTML = dep.nombre_departamento;
            o.value = dep.numero_departamento;
            select.appendChild(o);
        });
        hideLoading();
    });
}
// actualizar lista de clases
export function updateSelectClases(numCat, numDep, divId) {
    const select = document.getElementById(divId);
    select.innerHTML = "";
    const option = document.createElement("option");
    option.innerHTML = "Seleccionar Clase";
    option.value = 0;
    select.appendChild(option);
    if(!numCat || !numDep) {
        select.disabled = true;
        return;
    }
    showLoading();
    getDataFrom("clases", "numero_categoria="+numCat+"&numero_departamento="+numDep, data=>{ 
        if(!data) {
            alert("No se encontro informaón de Clases");
            return;
        }
        data = data.data || [];
        data = data.filter(d=>{
            return d.numero_departamento===numDep;
        });
        if(data<=0) return;
        
        select.disabled = false;
        data.forEach(dep=>{
            const o = document.createElement("option");
            o.innerHTML = dep.nombre_clase;
            o.value = dep.numero_clase;
            select.appendChild(o);
        });
        hideLoading();
    });
}
// actualizar lista de clases
export function updateSelectFamilias(numCat, numDep, numCla, divSelect) {
    const select = document.getElementById(divSelect);
    select.innerHTML = "";
    const option = document.createElement("option");
    option.innerHTML = "Seleccionar Familia";
    option.value = 0;
    select.appendChild(option);
    if(!numCat || !numDep || !numCla) {
        select.disabled = true;
        return;
    }
    showLoading();
    getDataFrom("familias", "numero_categoria="+numCat+"&numero_departamento="+numDep+"&numero_clase="+numCla, data=>{ 
        if(!data) {
            alert("No se encontro informaón de Familias");
            return;
        }
        data = data.data || [];
        data = data.filter(d=>{
            return d.numero_departamento===numDep &&
                    d.numero_clase===numCla;
        });
        if(data.length<=0) return;
        
        select.disabled = false;
        data.forEach(dep=>{
            const o = document.createElement("option");
            o.innerHTML = dep.nombre_familia;
            o.value = dep.numero_familia;
            select.appendChild(o);
        });
        hideLoading();
    });
}

