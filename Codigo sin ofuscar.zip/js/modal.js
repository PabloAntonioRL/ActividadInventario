/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {formatDate} from "./Util.js";

export function initModal() {
    const btn = document.getElementById("btnAceptModal");
    if(btn) btn.addEventListener("click", closeModal);
    const btnClose = document.getElementById("closeModal");
    btnClose.addEventListener("click", closeModal);
    
}

export function closeModal() {
    const modal = document.getElementById("modalSuccess");
    if(modal.className.indexOf("hidden")===-1)
        modal.classList.add("hidden");
}


export function showModal(content) {
    const modal = document.getElementById("modalSuccess");
    if(modal.className.indexOf("hidden")>=0)
        modal.classList.remove("hidden");
    if(content) {
        if(typeof content === "string") {
            const modalContent = document.getElementById("modalContent");
            modalContent.innerHTML = content;
        } else if(typeof content === "object") {
            const modalContent = document.getElementById("modalContent");
            modalContent.innerHTML = "";
            modalContent.appendChild(content);
        }
    }
}

export function createErrorPanel(title, message) {
    return `
        <div class="result-panel error-panel">
            <div class="result-icon">
                <img src="public/data/img/equis.png" width="100" heigh="100">
            </div>
            <div class="result-content">
                <h3>${title}</h3>
                <p class="danger-text">${message}</p>
            </div>
        </div>
    `;
}

export function createSuccessPanel(title, response) {
    let data = response.data;
    let details;
    if(!data) {
        details = "";
    } else {
        if(data[0]) data = data[0];
    }
    if(!data) {
        details = "";
    } else {
        
        details = Object.entries(data)
            .map(([key, value]) => {
                if(key.indexOf("fecha")>=0) {
                    let fecha = new Date(value).getTime();
                    let actual = new Date("2000-01-01").getTime();
                    if(fecha<actual) 
                        value = "-";
                    else
                        value = formatDate(value, "dd/mm/aaaa hh:mm");
                }
                return `
                    <div class="result-detail">
                        <span>${formatFieldName(key)}</span>
                        <strong>${value ?? '-'}</strong>
                    </div>
                `;
            })
            .join('');
    }

    return `
        <div class="result-panel success-panel">
            <div class="result-icon">
                <img src="public/data/img/check.png" width="100" heigh="100">
            </div>
            <div class="result-content">
                <h3>${title}</h3>
                <div class="result-details">
                    ${details}
                </div>
            </div>
        </div>
    `;
}

export function createWarningPanel(title, response, handeler) {
    const data = response.data || response;
    let details = "";
    if (data) {
        details = Object.entries(data)
            .map(([key, value]) => {
                if (key.indexOf("fecha") >= 0) {
                    let fecha = new Date(value).getTime();
                    let actual = new Date("2000-01-01").getTime();

                    if (fecha < actual)
                        value = "-";
                    else
                        value = formatDate(value, "dd/mm/aaaa hh:mm");
                }
                return `
                    <div class="result-detail">
                        <span>${formatFieldName(key)}</span>
                        <strong>${value ?? '-'}</strong>
                    </div>
                `;
            })
            .join('');
    }
    const panel = document.createElement("div");
    panel.className = "result-panel warning-panel";
    panel.innerHTML = `
        <div class="result-icon">
            <img src="public/data/img/warn.png" width="100" height="100">
        </div>

        <div class="result-content">
            <h3>${title}</h3>
            <p class="warning-text">${response.message || ''}</p>

            <div class="result-details">
                ${details}
            </div>
        </div>

        <div class="result-actions">
            <button type="button" class="btn btn-primary btn-cancel">
                Cancelar
            </button>

            <button type="button" class="btn btn-danger btn-accept">
                Aceptar
            </button>
        </div>
    `;

    // Obtener botones
    const btnAccept = panel.querySelector(".btn-accept");
    const btnCancel = panel.querySelector(".btn-cancel");
    // Registrar eventos
    btnAccept.addEventListener("click", () => {
        if (typeof handeler === "function")
            handeler(true);
        closeModal();
    });
    btnCancel.addEventListener("click", () => {
        if (typeof handeler === "function")
            handeler(false);
        closeModal();
    });
    return panel;
}

function formatFieldName(key) {
    return key
        .replace(/_/g, ' ')
        .replace(/\b\w/g, char => char.toUpperCase());
}