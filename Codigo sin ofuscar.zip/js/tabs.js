/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */


export function initializeTabs(container, initialTab = null) {
    const tabs = container.querySelectorAll("[data-tab]");
    const contents = container.querySelectorAll("[data-tab-content]");

    function selectTab(selectedTab) {
        const exists = Array.from(tabs).some(
            tab => tab.dataset.tab === selectedTab
        );

        if (!exists) return false;
        tabs.forEach(tab => {
            tab.classList.toggle(
                "active",
                tab.dataset.tab === selectedTab
            );
        });
        contents.forEach(content => {
            content.classList.toggle(
                "active",
                content.dataset.tabContent === selectedTab
            );
        });
        return true;
    }

    tabs.forEach(tab => {
        tab.addEventListener("click", () => {
            selectTab(tab.dataset.tab);
        });
    });

    if (initialTab !== null) {
        selectTab(initialTab);
    }
    return selectTab;
}

