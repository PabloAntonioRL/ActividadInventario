/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {formatLabel} from "./Util.js";
import { modules } from "./modules";
import { navigate } from "./router.js";

export function renderSidebar() {
    const sidebar = document.getElementById('sidebarMenu');
    sidebar.innerHTML = '';

    const parentMenu = document.createElement("ul");

    modules.forEach(m => {
        //--------------------------------------------------
        // Contenedor del nodo
        //--------------------------------------------------
        const item = document.createElement("div");
        item.className = "sidebar-node";
        parentMenu.appendChild(item);
        const row = document.createElement("div");
        row.className = "sidebar-row";

        item.appendChild(row);
//        const toggle = document.createElement("span");
//        toggle.className = "sidebar-toggle";
//        toggle.innerHTML = "▶";
//        row.appendChild(toggle);
        //--------------------------------------------------
        // Botón
        //--------------------------------------------------
        const button = document.createElement("div");
        button.className = "sidebar-item";
        button.style.paddingLeft = (20) + "px";
        button.dataset.module = m.id;
        button.textContent = formatLabel(m.title);
        button.onclick = () => navigate(m.id);
        row.appendChild(button);
//        const li = document.createElement('li');
//        li.className="sidebar-node";
//        li.textContent = m.title;
//        li.dataset.module = m.id;
//        li.onclick = () => navigate(m.id);
//        ul.appendChild(li);
    });

    sidebar.appendChild(parentMenu);
}

export function setActiveSidebar(moduleId) {
    document.querySelectorAll('#sidebar div').forEach(li => {
        li.classList.toggle('active', li.dataset.module === moduleId);
    });
}

