/* 
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/ClientSide/javascript.js to edit this template
 */
import {showModal, createErrorPanel, createSuccessPanel} from "./modal.js";
import {formatDate} from "./Util.js";


export async function submitEliminar(endpoint, pars, handeler) {
    try {
        if(!endpoint || !pars) return;
        
        const response = await fetch("http://localhost:8081/"+endpoint+"?"+pars, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al realizar la consulta.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible completar la consulta.");
        }
        showModal(createSuccessPanel("Consulta completada correctamente.", result));
        handeler(true);
    } catch (error) {
        console.error("Error al completar la consulta:", error);
        showModal(createErrorPanel("Error al completar la consulta", error.message));
        handeler(false);
    }
}

// Enviar información al endpoint
export async function submitCategoria(endpoint, datos, handeler) {
    try {
        if(!endpoint) return;
        const response = await fetch("http://localhost:8081/"+endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({data: datos})
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al registrar el categoria.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible registrar el categoria.");
        }
        showModal(createSuccessPanel("Categoria registrado correctamente.", result));
        handeler(true);
    } catch (error) {
        console.error("Error al registrar categoria:", error);
        showModal(createErrorPanel("Error al registrar categoria", error.message));
        handeler(false);
    }
}
// Enviar información al endpoint
export async function submitDepartamento(endpoint, datos, handeler) {
    try {
        if(!endpoint) return;
        const response = await fetch("http://localhost:8081/"+endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({data: datos})
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al registrar el departamento.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible registrar el departamento.");
        }
        showModal(createSuccessPanel("Departamento registrado correctamente.", result));
        handeler(true);
    } catch (error) {
        console.error("Error al registrar departamento:", error);
        showModal(createErrorPanel("Error al registrar departamento", error.message));
        handeler(false);
    }
}

// Enviar información al endpoint
export async function submitClase(endpoint, datos, handeler) {
    try {
        if(!endpoint) return;
        const response = await fetch("http://localhost:8081/"+endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({data: datos})
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al registrar Clase.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible registrar Clase.");
        }
        showModal(createSuccessPanel("Clase registrada correctamente.", result));
        handeler(true);
    } catch (error) {
        console.error("Error al registrar Calse:", error);
        showModal(createErrorPanel("Error al registrar clase", error.message));
        handeler(false);
    } 
}

// Enviar información al endpoint
export async function submitFamilia(endpoint, datos, handeler) {
    try {
        if(!endpoint) return;
        const response = await fetch("http://localhost:8081/"+endpoint, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({data: datos})
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al registrar la familia.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible registrar la famila.");
        }
        showModal(createSuccessPanel("Familia registrada correctamente.", result));
        handeler(true);
    } catch (error) {
        console.error("Error al registrar familia:", error);
        showModal(createErrorPanel("Error al registrar familia", error.message));
        handeler(false);
    }
}

// Enviar información al endpoint
export async function submitInventario(datos, handeler) {
    try {
        const response = await fetch("http://localhost:8081/newItem", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({data: datos})
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al registrar la articulo.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible registrar el articulo.");
        }
        if(result.data && result.data.length===1) {
            showModal(createSuccessPanel("Articulo registrado correctamente.", {
                code: result.code, message: result.message, data: result.data[0]}));
        } else {
            showModal(createSuccessPanel("Articulo registrado correctamente.", {
                code: result.code, message: result.message,
                data: null
            }));
        }
        
        handeler(true);
    } catch (error) {
        console.error("Error al registrar articulo:", error);
        showModal(createErrorPanel("Error al registrar articulo", error.message));
        handeler(false);
    }
}
// Enviar información al endpoint
export async function updateInventario(datos, handeler) {
    try {
        const response = await fetch("http://localhost:8081/updateItem", {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({data: datos})
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al registrar la articulo.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible registrar el articulo.");
        }
        if(result.data && result.data.length===1) {
            showModal(createSuccessPanel("Articulo registrado correctamente.", {
                code: result.code, message: result.message, data: result.data[0]}));
        } else {
            showModal(createSuccessPanel("Articulo registrado correctamente.", {
                code: result.code, message: result.message,
                data: null
            }));
        }
        
        handeler(true);
    } catch (error) {
        console.error("Error al registrar articulo:", error);
        showModal(createErrorPanel("Error al registrar articulo", error.message));
        handeler(false);
    }
}


export async function getDataFrom(table, filters, handeler) {
    try {
        console.log("Buscando datos de "+table);
        let pars = "from="+table;
        if(filters) pars+="&"+filters;
        const response = await fetch("http://localhost:8081/getData?"+pars, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const result = await response.json();
        console.log(result);
        handeler(result);
    } catch(e) {
        console.error(e);
        handeler(null, e.message);
        return null;
    }
}
export async function getInactiveFrom(table, filters, handeler) {
    try {
        console.log("Buscando datos de "+table);
        let pars = "from="+table;
        if(filters) pars+="&"+filters;
        const response = await fetch("http://localhost:8081/getDataInactive?"+pars, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const result = await response.json();
        console.log(result);
        handeler(result);
    } catch(e) {
        console.error(e);
        handeler(null, e.message);
        return null;
    }
}

export async function submitReactivar(pars, handeler) {
    try {
        console.log("Reactivando dato");
        const response = await fetch("http://localhost:8081/reactivateElement?"+pars, {
            method: "GET",
            headers: {
                "Content-Type": "application/json"
            }
        });
        const result = await response.json();
        if (!response.ok) {
            throw new Error(result.message || "Error al realizar la consulta.");
        }
        if (result.code !== 0) {
            throw new Error(result.message || "No fue posible completar la consulta.");
        }
        showModal(createSuccessPanel("Consulta completada correctamente.", result));
        console.log(result);
        handeler(result);
    } catch(e) {
        console.error(e);
        showModal(createErrorPanel("Error al completar la consulta", error.message));
        handeler(null, e.message);
        return null;
    }
}

